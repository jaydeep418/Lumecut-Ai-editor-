# Video export setup: FFmpeg

Stage 6's video export is a REAL server-side FFmpeg pipeline — not a browser
`MediaRecorder` capture, not a stub. FFmpeg (and `ffprobe`, which ships
alongside it in virtually every distribution) are **external system
dependencies this app does not bundle**. You must install them yourself on
whatever machine runs `server/`.

## Why not bundle a static binary?

Packages like `ffmpeg-static` bundle a precompiled FFmpeg binary as an npm
dependency, which is convenient — no separate install step. This project
deliberately does NOT do that, for a licensing reason worth knowing about:
most convenient static FFmpeg builds (including the ones such npm packages
ship) are compiled with GPL-licensed components (notably `libx264`, which this
pipeline uses for H.264 encoding). **Bundling and redistributing such a build
as part of your own app can carry GPL obligations for your distribution** —
this is a real legal consideration, not a formality, and it's yours to make
deliberately rather than inherit silently from an npm install.

Requiring a system-installed FFmpeg instead keeps that choice in your hands:
most Linux package managers' `ffmpeg` builds are LGPL-configured (no libx264,
i.e. no H.264 encoding) unless you specifically install or build a
GPL-enabled version — check what your install command actually gives you if
this matters for your distribution model.

If you decide the GPL trade-off is fine for your use case, you can still use a
static build: install the `ffmpeg-static` npm package yourself and set
`FFMPEG_PATH` (below) to its resolved binary path. That choice, and its
licensing consequences, would then be explicit and yours.

## Installing FFmpeg

**macOS (Homebrew):**
```bash
brew install ffmpeg
```

**Ubuntu/Debian:**
```bash
sudo apt-get update && sudo apt-get install -y ffmpeg
```
(Check `ffmpeg -encoders | grep libx264` afterward — some distros' default
`ffmpeg` package is built WITHOUT libx264 for licensing reasons. If it's
missing, you'll need a build that includes it, e.g. via a PPA or a manual
build, or the `ffmpeg-static` route above.)

**Windows:** download a build from https://www.gyan.dev/ffmpeg/builds/ (or
https://ffmpeg.org/download.html for other sources) and add its `bin/` folder
to your `PATH`.

**Verify it worked:**
```bash
ffmpeg -version
ffprobe -version
```
Both must succeed. The server itself checks this too — it logs
`[export] FFmpeg: available | ffprobe: available` on startup (or a clear
"NOT FOUND" warning), and the export route returns a clear 503 error rather
than a confusing crash if either is missing when someone tries to export.

## Environment variables

See `server/.env.example`. All optional — defaults assume `ffmpeg`/`ffprobe`
are on your system `PATH`.

- `FFMPEG_PATH` — path to the ffmpeg binary. Default: `ffmpeg` (resolved via PATH).
- `FFPROBE_PATH` — path to the ffprobe binary. Default: `ffprobe`.
- `FFMPEG_FONT_PATH` — a TrueType font file FFmpeg's `drawtext` filter uses to
  render text and sticker overlays. Defaults in code to
  `/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf` (present on most
  Debian/Ubuntu systems by default). **If that path doesn't exist on your
  machine, any export with a text or sticker overlay will fail** — set this
  explicitly to a font file you know exists. On macOS, for example, try
  `/System/Library/Fonts/Supplemental/Arial Bold.ttf`.
- `EXPORT_TMP_DIR` — where per-job temp files (uploaded clips + the rendered
  output) are written. Defaults to the OS temp directory (`os.tmpdir()`).
  Override this if your temp partition is small — 8K exports in particular can
  produce large intermediate and output files.

## Known limitations (stated plainly)

- **Emoji stickers do not render with the default font — confirmed by direct
  testing, not speculation.** An emoji drawn via `drawtext` with the default
  DejaVu Sans Bold font (this file's default `FFMPEG_FONT_PATH`) on a plain
  test background produced ZERO visible pixels — the font has no glyph for
  it, and FFmpeg draws nothing at all, not even a fallback box. A genuinely
  color-emoji-capable font (and an FFmpeg/library combination that can
  render it — support for color emoji in `drawtext` varies) would be needed
  for this to actually work. Point `FFMPEG_FONT_PATH` at one if this matters
  to you, and verify it renders before relying on it.
- **Overlay timing can drift slightly after a transition.** Text/sticker
  start/end times are stored against the pre-transition timeline; a real
  crossfade (via `xfade`/`acrossfade`) shortens the exported timeline from
  that point forward by the transition's duration, and overlay times are not
  currently re-adjusted for that shift. An overlay scheduled after a
  transition boundary may appear a little earlier than its stored time
  suggests, by the sum of transition overlaps before it.
- **Filter/transition looks are FFmpeg-native approximations**, not
  pixel-identical to the browser preview's CSS-based filters (they're built
  from different underlying primitives — see
  `server/src/services/export/ffmpegFilters.ts`).
- **The core filter-graph logic HAS been tested against a real FFmpeg
  binary** (found unexpectedly available in the environment this was built
  in) — trim, speed, reverse, rotate/flip, all color filters, hard cuts,
  real `xfade`/`acrossfade` transitions, muted/no-audio-source clips, text
  overlays, and exact 1080p/2K/4K/8K/24-30-60fps combinations were all run
  for real, and one genuine bug (an apostrophe in overlay text corrupting
  FFmpeg's filter-string quote-nesting) was found and fixed this way — see
  `PROJECT_PLAN.md`'s Stage 6 section for the full test log. **What was NOT
  tested**: the actual Express server as a running process (multer disk
  upload, the job manager's HTTP-facing progress/cancel endpoints), the
  browser frontend's upload/poll/download flow, and realistic-duration
  (rather than 1-second) 8K resource behavior. Test those specifically
  before relying on this in production.
