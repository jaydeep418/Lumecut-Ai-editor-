import { Router, type Response } from 'express';
import { aiProvider } from '../services/ai/index.js';
import { usageLimiter } from '../middleware/usageLimiter.js';
import { sniffImageMimeType, uploadImage } from '../middleware/validateUpload.js';

export const aiRouter = Router();

// Every AI route shares the same (demo-grade, pre-auth) usage limit.
aiRouter.use(usageLimiter);

/** Every provider adapter throws sanitized, human-readable Error messages (see
 *  services/ai/*Provider.ts) that never include our API key or the caller's raw
 *  request — safe to relay to the frontend as-is. Logs the same message
 *  server-side (never the request body/image bytes/prompt text) for debugging. */
function handleAiError(routeName: string, err: unknown, res: Response): void {
  const message = err instanceof Error ? err.message : 'AI processing failed';
  // eslint-disable-next-line no-console
  console.error(`[ai] ${routeName} failed: ${message}`);
  res.status(502).json({ status: 'error', message });
}

aiRouter.post('/photo/remove-background', (req, res) => {
  uploadImage(req, res, async (uploadErr) => {
    if (uploadErr) {
      res.status(413).json({ status: 'error', message: uploadErr.message });
      return;
    }
    if (!req.file) {
      res.status(400).json({ status: 'error', message: 'No image uploaded' });
      return;
    }
    const sniffedMimeType = sniffImageMimeType(req.file.buffer);
    if (!sniffedMimeType) {
      res.status(400).json({ status: 'error', message: 'The uploaded file does not look like a supported image' });
      return;
    }
    try {
      const result = await aiProvider.removeBackground(req.file.buffer, sniffedMimeType);
      res.json({
        status: 'done',
        resultUrl: `data:${result.resultMimeType};base64,${result.resultBuffer.toString('base64')}`,
      });
    } catch (err) {
      handleAiError('remove-background', err, res);
    }
  });
});

aiRouter.post('/photo/enhance', (req, res) => {
  uploadImage(req, res, async (uploadErr) => {
    if (uploadErr) {
      res.status(413).json({ status: 'error', message: uploadErr.message });
      return;
    }
    if (!req.file) {
      res.status(400).json({ status: 'error', message: 'No image uploaded' });
      return;
    }
    const sniffedMimeType = sniffImageMimeType(req.file.buffer);
    if (!sniffedMimeType) {
      res.status(400).json({ status: 'error', message: 'The uploaded file does not look like a supported image' });
      return;
    }
    try {
      const result = await aiProvider.enhancePhoto(req.file.buffer, sniffedMimeType);
      res.json({
        status: 'done',
        resultUrl: `data:${result.resultMimeType};base64,${result.resultBuffer.toString('base64')}`,
      });
    } catch (err) {
      handleAiError('enhance', err, res);
    }
  });
});

aiRouter.post('/video/script', async (req, res) => {
  const prompt = typeof req.body?.prompt === 'string' ? req.body.prompt : '';
  try {
    const result = await aiProvider.generateScript(prompt);
    res.json({ status: 'done', text: result.text });
  } catch (err) {
    handleAiError('script', err, res);
  }
});
