import { Router } from 'express';
import fs from 'fs';
import { usageLimiter } from '../middleware/usageLimiter.js';
import { createVideoUpload } from '../middleware/validateVideoUpload.js';
import { isFfmpegAvailable, isFfprobeAvailable } from '../services/export/ffmpegBinary.js';
import { cancelExportJob, cleanupExportJob, createExportJob, getExportJob, runExportJob } from '../services/export/exportJobManager.js';
import type { ExportRequestManifest } from '../services/export/types.js';

export const exportRouter = Router();

// Applied only to the route that STARTS a new export job — NOT to progress
// polling/cancel/result, which happen repeatedly (every ~1s) for a single
// already-counted job and would otherwise exhaust the per-session limit
// within seconds of any export starting.
exportRouter.post('/video', usageLimiter, (req, res) => {
  if (!isFfmpegAvailable() || !isFfprobeAvailable()) {
    res.status(503).json({
      status: 'error',
      message: 'FFmpeg is not installed or not on PATH on this server. See server/EXPORT_SETUP.md.',
    });
    return;
  }

  const job = createExportJob();
  const upload = createVideoUpload(job.tempDir);

  upload(req, res, (uploadErr) => {
    if (uploadErr) {
      cleanupExportJob(job.id);
      res.status(413).json({ status: 'error', message: uploadErr.message });
      return;
    }

    let manifest: ExportRequestManifest;
    try {
      manifest = JSON.parse(req.body?.manifest ?? '');
    } catch {
      cleanupExportJob(job.id);
      res.status(400).json({ status: 'error', message: 'Invalid export request: manifest was not valid JSON.' });
      return;
    }

    if (!manifest?.clips?.length || !manifest.width || !manifest.height || !manifest.fps) {
      cleanupExportJob(job.id);
      res.status(400).json({ status: 'error', message: 'Invalid export request: manifest is missing required fields.' });
      return;
    }

    const files = Array.isArray(req.files) ? req.files : [];
    const filePathBySourceKey = new Map<string, string>();
    for (const file of files) {
      filePathBySourceKey.set(file.fieldname, file.path);
    }

    const missingSource = manifest.clips.find((c) => !filePathBySourceKey.has(c.sourceKey));
    if (missingSource) {
      cleanupExportJob(job.id);
      res.status(400).json({ status: 'error', message: 'Invalid export request: a clip referenced a file that was not uploaded.' });
      return;
    }

    res.json({ status: 'started', jobId: job.id });
    runExportJob(job, manifest, filePathBySourceKey);
  });
});

exportRouter.get('/video/:jobId/progress', (req, res) => {
  const job = getExportJob(req.params.jobId);
  if (!job) {
    res.status(404).json({ status: 'error', message: 'Export job not found (it may have expired).' });
    return;
  }
  res.json({ status: job.status, progressRatio: job.progressRatio, message: job.errorMessage });
});

exportRouter.post('/video/:jobId/cancel', (req, res) => {
  const cancelled = cancelExportJob(req.params.jobId);
  res.json({ status: cancelled ? 'cancelled' : 'not_found' });
});

exportRouter.get('/video/:jobId/result', (req, res) => {
  const job = getExportJob(req.params.jobId);
  if (!job || job.status !== 'done' || !job.outputPath || !fs.existsSync(job.outputPath)) {
    res.status(404).json({ status: 'error', message: 'Export result not available.' });
    return;
  }

  res.download(job.outputPath, 'export.mp4', (err) => {
    // Clean up the job's temp directory once the file has been sent (or the
    // download failed partway) — either way, nothing else will ever need it.
    if (err) {
      // eslint-disable-next-line no-console
      console.error('[export] Error sending result file:', err.message);
    }
    cleanupExportJob(job.id);
  });
});
