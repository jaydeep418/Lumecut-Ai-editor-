# Payments / billing service

Populated in Stage 8. Holds `env.BILLING_SECRET_KEY` and `env.BILLING_WEBHOOK_SECRET`
— nowhere else. Exposes an interface (`createSubscription`, `verifyEntitlement`,
`handleWebhook`, `restorePurchases`) so the billing provider (Stripe, RevenueCat, Google
Play Billing via a native plugin) is swappable without touching call sites.
