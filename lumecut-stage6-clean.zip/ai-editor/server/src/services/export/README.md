# Video export service (Stage 6 — real FFmpeg pipeline)

Replaces the earlier browser-`MediaRecorder`-based export entirely. This is a
real server-side FFmpeg pipeline: the frontend uploads the actual clip bytes
plus a JSON manifest describing the EDL (trim/speed/reverse/rotate/flip/
filter/transitions/overlays), and this service constructs and runs a real
`ffmpeg` process that produces an actual MP4 file.

See `server/EXPORT_SETUP.md` for FFmpeg installation/configuration and its
licensing note, and this folder's files for the pipeline itself:

- `types.ts` — the manifest contract (`ExportRequestManifest`) and job state
  shape. `sourceKey` (not the browser's `sourceUrl`, which is meaningless
  server-side) references one of the uploaded files in the same request —
  clips sharing a source (e.g. a split clip's two halves) share a `sourceKey`
  so the file is uploaded and decoded once.
- `ffmpegBinary.ts` — resolves and health-checks the `ffmpeg`/`ffprobe`
  binaries (external system dependencies, not bundled — see EXPORT_SETUP.md).
- `ffmpegFilters.ts` — maps our `FilterId` presets to real FFmpeg filter
  expressions (best-effort visual approximation of the browser preview's
  CSS-based look — not pixel-identical, documented as such).
- `probe.ts` — `ffprobe`-based check for whether a source file actually has an
  audio stream, so the filter graph can substitute generated silence instead
  of referencing a stream that doesn't exist (which would otherwise fail the
  whole export).
- `buildFilterGraph.ts` — the core piece: constructs the full
  `filter_complex` graph — per-clip trim/reverse/speed/rotate/flip/color
  filter/cover-fit-scale/fps, then chains clips together using REAL `xfade`
  (video) + `acrossfade` (audio) at a Fade transition, or `concat` for a hard
  cut, then applies text/sticker overlays via `drawtext` on the final merged
  stream.
- `exportJobManager.ts` — job lifecycle: creates a per-job temp directory,
  spawns the actual `ffmpeg` process with `-progress pipe:1` for real
  progress (parsed from FFmpeg's own `out_time_ms`, not simulated), supports
  cancellation (kills the process), cleans up temp files, and sweeps jobs a
  client never finished polling/downloading.

## Why clips are re-uploaded per export

Clips exist in the browser only as `blob:` object URLs (Stage 2's file
picker) — private to the tab, invisible to this server. There's no persistent
cloud storage yet (Stage 9), so every export re-uploads the relevant clip
bytes fresh. This is the same architectural pattern Stage 5 already
established for AI photo tools (`features/ai/photoAiService.ts`'s
`blobUrlToBlob`), extended here for video.

## Documented limitations

See `server/EXPORT_SETUP.md`'s "Known limitations" section for the full list
(emoji sticker rendering, overlay timing after a transition, filter-look
approximation) and, most importantly, the precise account of what WAS tested
against a real FFmpeg binary (most of the core pipeline — see the test log
there) versus what wasn't (the actual Express server process and the browser
frontend, which this sandbox couldn't run).
