# Auth service

Populated in Stage 9. Wraps whichever provider is chosen (Firebase Auth / Supabase
Auth) behind an interface so route handlers call `auth.verifyToken()`,
`auth.getUser()`, etc. rather than a provider SDK directly.
