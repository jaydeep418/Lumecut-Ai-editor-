/**
 * The contract every AI provider implementation (mock or real) fulfills. Routes in
 * api/ai.ts call ONLY this interface — never a concrete provider class directly —
 * so swapping providers later never touches route code.
 *
 * Split into three small capability interfaces because each is backed by a
 * genuinely DIFFERENT real, independently-documented provider — remove.bg for
 * background removal, DeepAI for photo enhancement, OpenAI for script generation
 * (see removeBgProvider.ts / deepAiProvider.ts / openAiScriptProvider.ts). There
 * is no single generic "AI provider API" to invent a contract for; `index.ts`
 * assembles the combined `AiProvider` from whichever of the three is configured,
 * falling back to MockAiProvider independently per capability.
 */

export interface ProviderImageResult {
  resultBuffer: Buffer;
  resultMimeType: string;
}

export interface ProviderTextResult {
  text: string;
}

export interface BackgroundRemovalProvider {
  removeBackground(imageBuffer: Buffer, mimeType: string): Promise<ProviderImageResult>;
}

export interface PhotoEnhanceProvider {
  enhancePhoto(imageBuffer: Buffer, mimeType: string): Promise<ProviderImageResult>;
}

export interface ScriptProvider {
  generateScript(prompt: string): Promise<ProviderTextResult>;
}

export interface AiProvider extends BackgroundRemovalProvider, PhotoEnhanceProvider, ScriptProvider {}
