import type { AiProvider, ProviderImageResult, ProviderTextResult } from './types.js';

/**
 * DEV MOCK — not real AI processing, not for production use.
 *
 * Used per-capability as a fallback whenever that capability's specific provider
 * key isn't configured (REMOVE_BG_API_KEY / DEEPAI_API_KEY / OPENAI_API_KEY — see
 * ./index.ts, which assembles the real `AiProvider` from whichever of the three
 * real adapters are configured, falling back to this mock independently per
 * method). Exists so the full request path (upload → route → provider → response
 * → frontend render) can be built, run, and demoed without any paid API key.
 * Image methods pass the original bytes straight through; the script method
 * returns a clearly-labeled canned outline. Nothing here should ever be mistaken
 * for a real model's output.
 */
export class MockAiProvider implements AiProvider {
  async removeBackground(imageBuffer: Buffer, mimeType: string): Promise<ProviderImageResult> {
    return { resultBuffer: imageBuffer, resultMimeType: mimeType };
  }

  async enhancePhoto(imageBuffer: Buffer, mimeType: string): Promise<ProviderImageResult> {
    return { resultBuffer: imageBuffer, resultMimeType: mimeType };
  }

  async generateScript(prompt: string): Promise<ProviderTextResult> {
    const topic = prompt.trim() || 'your video';
    return {
      text: [
        '[MOCK SCRIPT — no real AI provider is configured; this is a canned placeholder]',
        '',
        `Hook (0-2s): Open with the single most surprising thing about "${topic}".`,
        'Body (2-20s): Three short beats that build on the hook, one idea per beat.',
        'CTA (last 2s): One clear, short call to action.',
      ].join('\n'),
    };
  }
}
