# Video processing service

Populated in Stage 4 (basic operations) and Stage 6 (export). Wraps server-side FFmpeg
for operations that are too heavy, slow, or format-sensitive to run reliably in-browser
(true 4K/2K encodes, format transcoding, audio mixing/mux). Real-time preview/trim/split
scrubbing stays client-side (browser Canvas/WebCodecs) for responsiveness; only the
final render pipeline necessarily comes through here.
