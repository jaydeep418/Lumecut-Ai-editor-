# Shared backend types

Populated as each stage introduces its domain model, e.g.:

- Stage 4/6: `Project`, `Clip`, `ExportJob`
- Stage 5: `AiJobRequest`, `AiJobResult`
- Stage 8: `Subscription`, `Entitlement`
- Stage 9: `User`, `Session`

Types shared with the frontend (e.g. the shape of `/api/health`'s response) should stay
small and be duplicated explicitly on the `web/` side rather than imported across the
package boundary, to keep `web/` and `server/` independently deployable.
