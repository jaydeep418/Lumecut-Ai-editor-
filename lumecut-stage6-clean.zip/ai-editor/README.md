# Lumecut — AI Photo & Video Editor

> Working codename: **Lumecut**. Change freely in `config/app.config.json` before shipping —
> it is not used anywhere as a hardcoded string outside that file and this README.

An original, mobile-first AI photo & video editor. Web app built with React + TypeScript,
packaged for Android via Capacitor, backed by a Node.js + TypeScript API that fronts all
AI providers, payments, and ad configuration so no secret key ever ships to a device.

This repository is being built in stages (see `PROJECT_PLAN.md`). **This commit is Stage 1
only**: architecture, folder structure, tooling, and environment configuration. No feature
UI or business logic has been written yet — that starts at Stage 2.

## Monorepo layout

```
ai-editor/
├── web/            React + TypeScript + Vite frontend (mobile-first, wraps in Capacitor)
├── server/         Node.js + TypeScript backend API (auth, AI proxy, payments, ads config)
├── android/        Capacitor Android project (generated in Stage 11 — empty placeholder now)
├── config/         Shared, non-secret app configuration (plan pricing, feature flags, etc.)
└── PROJECT_PLAN.md Stage-by-stage build plan and current status
```

## Why this stack

- **React + TypeScript + Vite (web/)** — fast dev server, small production bundles, huge
  ecosystem of canvas/WebGL/video libraries we'll need for the photo/video editors.
- **Capacitor (Stage 11)** — wraps the same React app as a real Android app with access to
  native filesystem, camera, and in-app billing plugins, instead of a second native codebase.
- **Node.js + TypeScript (server/)** — one language across the stack; easy to isolate secret
  API keys (AI providers, payment processors, ad mediation) behind authenticated endpoints.
- **FFmpeg (server-side, added in Stage 6)** — for export operations that are too heavy or
  unreliable to do purely client-side (true 4K encode, format conversion, audio mixing).
  Lighter, real-time preview operations will use browser-native APIs (Canvas/WebCodecs).
- **Firebase or Supabase (Stage 9, your choice)** — both offer managed auth + Postgres/NoSQL
  + object storage with mobile SDKs, avoiding hand-rolled auth infrastructure.

Nothing here is locked in — the AI provider layer, ad provider, payment provider, and
database are all designed as swappable interfaces (see `server/src/services/*`).

## Requirements

- Node.js 20 LTS or newer
- npm 10+
- Android Studio (only needed starting Stage 11)
- A `.env` file in `web/` and one in `server/` (copy from the `.env.example` in each)

## Setup (Stage 1)

```bash
# from the ai-editor/ root

# 1. Install frontend dependencies
cd web
npm install
cp .env.example .env
cd ..

# 2. Install backend dependencies
cd server
npm install
cp .env.example .env
cd ..
```

## Running (Stage 1 — sanity check only)

At Stage 1 there is no UI yet, just the scaffolding, so "running" it only proves the
toolchain is wired correctly:

```bash
# Frontend dev server (should show a blank "Lumecut — Stage 1 OK" placeholder page)
cd web
npm run dev

# Backend dev server (should expose GET /api/health -> { "status": "ok" })
cd server
npm run dev
```

Verify the backend health check:

```bash
curl http://localhost:8787/api/health
```

Expected response:

```json
{ "status": "ok", "stage": 5 }
```

If both of those work, Stage 1 is stable and we move to Stage 2 (Home + navigation +
project creation).

## Environment variables

See `web/.env.example` and `server/.env.example` for the full list. None of the AI
provider, payments, or ad-network keys exist yet in Stage 1 — they are documented now so
the shape of the config is stable, and they'll be consumed starting in Stages 5, 7, and 8.
**No secret key is ever read on the `web/` side** — the frontend only ever holds public,
non-sensitive config (API base URL, publishable/client IDs, feature flags).
