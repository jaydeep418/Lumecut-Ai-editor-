import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import { fileURLToPath } from 'url';

// `fileURLToPath(new URL(..., import.meta.url))` instead of `__dirname` —
// this project's `type: module` + bundler-mode tsconfig means __dirname
// would need @types/node, which web/package.json deliberately doesn't carry
// (unlike server/package.json, which actually uses Node's fs/path/os APIs at
// runtime). The import.meta.url form works natively in ESM with zero extra
// type dependency, and is the approach Vite's own docs recommend for this.
const srcDir = fileURLToPath(new URL('./src', import.meta.url));

// Mobile-first target: keep bundles small, split heavy editor code lazily (Stage 3+).
export default defineConfig({
  plugins: [react()],
  resolve: {
    alias: {
      '@': srcDir,
      '@features': `${srcDir}/features`,
      '@components': `${srcDir}/components`,
      '@services': `${srcDir}/services`,
      '@hooks': `${srcDir}/hooks`,
      '@utils': `${srcDir}/utils`,
      '@types': `${srcDir}/types`,
    },
  },
  server: {
    port: 5173,
    strictPort: true,
  },
  build: {
    target: 'es2020',
    // Video/photo processing libs (added from Stage 3 onward) tend to be large;
    // manualChunks keeps the initial load light. Extended as features land.
    rollupOptions: {
      output: {
        manualChunks: {
          vendor: ['react', 'react-dom', 'react-router-dom'],
        },
      },
    },
  },
});
