import { getSessionId } from '@services/sessionId';

/**
 * Photo AI service abstraction.
 *
 * This file defines the CONTRACT the editor UI programs against. Stage 5 wires up
 * a real implementation (`BackendPhotoAiService`, below) for two of the six photo
 * AI tools — Background Remover and Photo Enhancer — as a representative,
 * end-to-end example of the image-upload-in/image-out request shape. The
 * remaining tools (Background Replacement, Upscaler, Object Removal, Effects)
 * stay stubbed with a clear "not part of this stage" message; wiring each up
 * follows the exact same pattern (a method here, a route in server/src/api/ai.ts,
 * a provider method in server/src/services/ai).
 *
 * `BackendPhotoAiService` never talks to an AI provider directly — it only ever
 * calls this app's OWN backend (`/api/ai/*`), which holds the real provider
 * key server-side. No API key of any kind lives in this file or anywhere else in
 * `web/`.
 */

export type AiJobStatus = 'unavailable' | 'queued' | 'processing' | 'done' | 'error';

export interface AiJobResult {
  status: AiJobStatus;
  /** Populated only when status === 'done' and the result is an image. */
  resultUrl?: string;
  message?: string;
}

export interface PhotoAiService {
  removeBackground(sourceUrl: string): Promise<AiJobResult>;
  replaceBackground(sourceUrl: string, promptOrBackgroundId: string): Promise<AiJobResult>;
  enhance(sourceUrl: string): Promise<AiJobResult>;
  upscale(sourceUrl: string, factor: 2 | 4): Promise<AiJobResult>;
  applyEffect(sourceUrl: string, effectId: string): Promise<AiJobResult>;
}

const NOT_IN_THIS_STAGE: AiJobResult = {
  status: 'unavailable',
  message: 'Not part of this Stage 5 build — same interface as Background Remover/Enhancer, ready to wire the same way.',
};

/** Kept for reference/testing — reports every tool as unavailable, makes no calls. */
export class StubPhotoAiService implements PhotoAiService {
  async removeBackground(): Promise<AiJobResult> {
    return NOT_IN_THIS_STAGE;
  }
  async replaceBackground(): Promise<AiJobResult> {
    return NOT_IN_THIS_STAGE;
  }
  async enhance(): Promise<AiJobResult> {
    return NOT_IN_THIS_STAGE;
  }
  async upscale(): Promise<AiJobResult> {
    return NOT_IN_THIS_STAGE;
  }
  async applyEffect(): Promise<AiJobResult> {
    return NOT_IN_THIS_STAGE;
  }
}

const API_BASE_URL = import.meta.env.VITE_API_BASE_URL ?? 'http://localhost:8787';

/** The browser's blob: URLs (from Stage 2/3's file picker) only exist inside this
 *  tab — a Node backend can't fetch them. This re-fetches the SAME blob URL
 *  client-side (which works fine; it's the same origin/tab that created it) to get
 *  real bytes to upload. */
async function blobUrlToBlob(sourceUrl: string): Promise<Blob> {
  const response = await fetch(sourceUrl);
  if (!response.ok) throw new Error('Could not read the local file to upload');
  return response.blob();
}

/** Real implementation: uploads actual image bytes to this app's own backend and
 *  renders back whatever it returns. Never holds or sees a provider API key. */
export class BackendPhotoAiService implements PhotoAiService {
  async removeBackground(sourceUrl: string): Promise<AiJobResult> {
    return this.uploadImage('/api/ai/photo/remove-background', sourceUrl);
  }

  async enhance(sourceUrl: string): Promise<AiJobResult> {
    return this.uploadImage('/api/ai/photo/enhance', sourceUrl);
  }

  async replaceBackground(): Promise<AiJobResult> {
    return NOT_IN_THIS_STAGE;
  }
  async upscale(): Promise<AiJobResult> {
    return NOT_IN_THIS_STAGE;
  }
  async applyEffect(): Promise<AiJobResult> {
    return NOT_IN_THIS_STAGE;
  }

  private async uploadImage(path: string, sourceUrl: string): Promise<AiJobResult> {
    try {
      const blob = await blobUrlToBlob(sourceUrl);
      const formData = new FormData();
      formData.append('image', blob, 'image.png');

      const response = await fetch(`${API_BASE_URL}${path}`, {
        method: 'POST',
        headers: { 'X-Session-Id': getSessionId() },
        body: formData,
      });
      const data = await response.json();

      if (!response.ok) {
        return { status: 'error', message: typeof data?.message === 'string' ? data.message : 'AI processing failed' };
      }
      return { status: 'done', resultUrl: data.resultUrl };
    } catch (err) {
      return { status: 'error', message: err instanceof Error ? err.message : 'AI processing failed' };
    }
  }
}

let activeService: PhotoAiService = new BackendPhotoAiService();

/** Swaps the active implementation — e.g. back to the stub for testing, or to a
 *  future alternative backend integration. Every call site below keeps using
 *  `photoAiService` unchanged regardless of which implementation is active. */
export function setPhotoAiService(service: PhotoAiService): void {
  activeService = service;
}

export const photoAiService: PhotoAiService = {
  removeBackground: (sourceUrl) => activeService.removeBackground(sourceUrl),
  replaceBackground: (sourceUrl, promptOrBackgroundId) => activeService.replaceBackground(sourceUrl, promptOrBackgroundId),
  enhance: (sourceUrl) => activeService.enhance(sourceUrl),
  upscale: (sourceUrl, factor) => activeService.upscale(sourceUrl, factor),
  applyEffect: (sourceUrl, effectId) => activeService.applyEffect(sourceUrl, effectId),
};
