# AI Tools feature (frontend)

`photoAiService.ts` (Stage 3) defines the interface the photo editor's AI panel
programs against — `removeBackground`, `replaceBackground`, `enhance`, `upscale`,
`applyEffect` — plus a stub implementation that always resolves with status
`'unavailable'` and makes no network call, holds no API key, and imports no provider
SDK.

Stage 5 adds a real implementation that calls the backend's `/api/ai/*` routes (see
server/src/services/ai) and swaps it in via `setPhotoAiService()`. No changes needed
in `AiToolsPanel` or anywhere else that calls `photoAiService` — that's the point of
programming against the interface now.

`videoAiService.ts` (Stage 4) follows the identical pattern for the video editor:
`generateCaptions`, `generateSubtitles`, `applyVideoEffect`, `generateScript`,
`generateCaptionText` — same stub behavior, same `setVideoAiService()` swap-in point
for Stage 5.
