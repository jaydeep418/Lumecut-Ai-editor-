import { useEffect, useRef } from 'react';
import type { VideoClip } from './types';

/**
 * One real `<video>` element per clip — never appended to the DOM (video elements
 * decode and can be drawn via `ctx.drawImage` without being visible), never
 * recreated on every render. This is the ONLY place clip playback state (which
 * elements exist, their play/pause/currentTime) is managed; VideoCanvas only ever
 * reads the current frame from whichever element this hook says is active.
 *
 * No manual frame decoding happens anywhere here — the browser's native video
 * decoder does that; we only set `.src`, `.currentTime`, `.playbackRate`, and call
 * `.play()`/`.pause()`.
 */
export function useClipPlayers(clips: VideoClip[], onMetadataLoaded: (clipId: string, durationSeconds: number) => void) {
  const playersRef = useRef<Map<string, HTMLVideoElement>>(new Map());
  const onMetadataLoadedRef = useRef(onMetadataLoaded);
  onMetadataLoadedRef.current = onMetadataLoaded;

  useEffect(() => {
    const players = playersRef.current;
    const currentIds = new Set(clips.map((c) => c.id));

    // Create players for any new clips.
    for (const clip of clips) {
      if (players.has(clip.id)) continue;
      const video = document.createElement('video');
      video.src = clip.sourceUrl;
      video.preload = 'auto';
      video.muted = false;
      video.playsInline = true;
      video.crossOrigin = 'anonymous';
      video.addEventListener('loadedmetadata', () => {
        onMetadataLoadedRef.current(clip.id, video.duration || 0);
      });
      players.set(clip.id, video);
    }

    // Tear down players for clips that were removed.
    for (const [id, video] of players) {
      if (!currentIds.has(id)) {
        video.pause();
        video.removeAttribute('src');
        video.load();
        players.delete(id);
      }
    }
  }, [clips]);

  // Full teardown on unmount.
  useEffect(() => {
    const players = playersRef.current;
    return () => {
      for (const video of players.values()) {
        video.pause();
        video.removeAttribute('src');
        video.load();
      }
      players.clear();
    };
  }, []);

  function getPlayer(clipId: string): HTMLVideoElement | undefined {
    return playersRef.current.get(clipId);
  }

  return { getPlayer };
}
