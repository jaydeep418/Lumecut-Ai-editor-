/** Resolves once a video's metadata (duration) is available. Used right when a clip
 *  is imported so it enters the EDL with a correct `outPoint` from the start —
 *  avoiding a separate "metadata just loaded, patch the state" history entry later. */
export function probeVideoDuration(url: string): Promise<number> {
  return new Promise((resolve, reject) => {
    const video = document.createElement('video');
    video.preload = 'metadata';
    video.onloadedmetadata = () => {
      resolve(video.duration || 0);
      video.src = '';
    };
    video.onerror = () => reject(new Error(`Failed to read video metadata: ${url}`));
    video.src = url;
  });
}
