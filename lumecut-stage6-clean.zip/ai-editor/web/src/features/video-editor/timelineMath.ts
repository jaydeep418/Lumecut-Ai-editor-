import { clipTimelineDuration, type Transition, type VideoClip } from './types';

export interface PlayheadResolution {
  clip: VideoClip;
  clipIndex: number;
  /** Where this clip starts on the TIMELINE, seconds. */
  timelineStart: number;
  /** This clip's own duration on the timeline (already speed-adjusted), seconds. */
  timelineDuration: number;
  /** How far into the clip's timeline slot the playhead is, 0..timelineDuration. */
  localTimelineOffset: number;
  /** The corresponding time in the clip's SOURCE file — what to seek its <video> to. */
  sourceTime: number;
}

export function computeTotalTimelineDuration(clips: VideoClip[]): number {
  return clips.reduce((sum, clip) => sum + clipTimelineDuration(clip), 0);
}

/**
 * Resolves a single global timeline time into "which clip is active, and where in
 * that clip's own source file are we" — the one function every playback and
 * rendering concern (VideoCanvas, useClipPlayers, Timeline scrubber) builds on.
 * Returns null for an empty timeline or a time past the end.
 */
export function resolvePlayhead(clips: VideoClip[], timelineTime: number): PlayheadResolution | null {
  let cursor = 0;
  for (let i = 0; i < clips.length; i++) {
    const clip = clips[i];
    const duration = clipTimelineDuration(clip);
    if (duration <= 0) continue;

    const end = cursor + duration;
    // Treat the very end of the timeline as still belonging to the last clip
    // (timelineTime === totalDuration would otherwise fall through as "past the end").
    const isLastClip = i === clips.length - 1;
    if (timelineTime < end || (isLastClip && timelineTime <= end)) {
      const localTimelineOffset = Math.min(duration, Math.max(0, timelineTime - cursor));
      const sourceProgress = localTimelineOffset * clip.speed;
      const sourceTime = clip.reversed ? clip.outPoint - sourceProgress : clip.inPoint + sourceProgress;
      return {
        clip,
        clipIndex: i,
        timelineStart: cursor,
        timelineDuration: duration,
        localTimelineOffset,
        sourceTime,
      };
    }
    cursor = end;
  }
  return null;
}

export interface TransitionBlend {
  fromClip: VideoClip;
  toClip: VideoClip;
  /** 0 = fully fromClip, 1 = fully toClip. */
  alpha: number;
}

/**
 * Preview-only fade approximation (Stage 4 scope — the real crossfade render is
 * Stage 6's job): rather than shortening the overall timeline by overlapping two
 * clips' durations (which would require touching `resolvePlayhead`/
 * `computeTotalTimelineDuration` and every piece of code built on them), the fade
 * plays out entirely within the OUTGOING clip's own last `duration` seconds,
 * blending toward the incoming clip's very first frame. This keeps the timeline
 * math completely unchanged and is a reasonable in-editor preview approximation.
 */
export function resolveTransitionBlend(
  clips: VideoClip[],
  transitions: Transition[],
  timelineTime: number
): TransitionBlend | null {
  const resolution = resolvePlayhead(clips, timelineTime);
  if (!resolution) return null;

  const transition = transitions.find((t) => t.afterClipId === resolution.clip.id && t.type === 'fade');
  if (!transition || transition.duration <= 0) return null;

  const nextClip = clips[resolution.clipIndex + 1];
  if (!nextClip) return null;

  const windowStart = resolution.timelineDuration - transition.duration;
  if (resolution.localTimelineOffset < windowStart) return null;

  const alpha = Math.min(1, Math.max(0, (resolution.localTimelineOffset - windowStart) / transition.duration));
  return { fromClip: resolution.clip, toClip: nextClip, alpha };
}
