import type { FilterId } from '@/features/shared/filters';

/**
 * Non-destructive video edit state (an "EDL" — edit decision list).
 *
 * No client-side re-encoding happens in Stage 4. Every clip stores where it sits in
 * its SOURCE file (`inPoint`/`outPoint`) plus playback decisions (speed, reverse,
 * volume, filter, transform) as plain data. Trim/split/merge/speed/reverse all just
 * edit this data — never the underlying video file. Stage 6's export pipeline reads
 * this same schema to drive the real FFmpeg render, so it's kept deterministic and
 * serializable (safe to hand to a backend job later, not just used in-browser).
 */

export interface VideoClip {
  id: string;
  /** Object URL for this clip's own source file — independent of any other clip's,
   *  and independent of the project's original `previewUrl` (see
   *  useVideoEditor's initial-clip-seeding effect). */
  sourceUrl: string;
  name: string;
  /** Full duration of the source file, seconds. 0 until metadata loads. */
  sourceDuration: number;
  /** Trim in/out points into the SOURCE, seconds. outPoint > inPoint. */
  inPoint: number;
  outPoint: number;
  /** Playback speed multiplier (0.25–4 in the Stage 4 UI). Affects how much
   *  TIMELINE time this clip occupies: timelineDuration = (outPoint - inPoint) / speed. */
  speed: number;
  /** Reverse is an edit DECISION, not a live preview capability — HTML5 video has no
   *  reliable native reverse playback. Stage 4 marks it and previews it via manual
   *  scrubbing (see useClipPlayers); Stage 6's FFmpeg pass does the real reverse render. */
  reversed: boolean;
  volume: number; // 0..1
  muted: boolean;
  rotationDeg: 0 | 90 | 180 | 270;
  flipHorizontal: boolean;
  flipVertical: boolean;
  filter: FilterId;
  /** Non-destructive "merge": clips sharing a groupId are presented as one
   *  continuous unit (no transition breaks between them, grouped visually on the
   *  timeline) while each retains its own sourceUrl/inPoint/outPoint/edit
   *  decisions. No re-encoding, no physical file combination — Stage 6's FFmpeg
   *  renderer can treat consecutive same-groupId clips as one concatenated segment
   *  deterministically, using each clip's own trim/speed/reverse as-is. null = not
   *  part of any merged group. */
  groupId: string | null;
}

export function createClipFromFile(sourceUrl: string, name: string): VideoClip {
  return {
    id: crypto.randomUUID(),
    sourceUrl,
    name,
    sourceDuration: 0,
    inPoint: 0,
    outPoint: 0, // set once metadata loads (see useClipPlayers)
    speed: 1,
    reversed: false,
    volume: 1,
    muted: false,
    rotationDeg: 0,
    flipHorizontal: false,
    flipVertical: false,
    filter: 'none',
    groupId: null,
  };
}

export function clipTimelineDuration(clip: VideoClip): number {
  return Math.max(0, (clip.outPoint - clip.inPoint) / clip.speed);
}

export type TransitionType = 'none' | 'fade';

export interface Transition {
  /** The transition plays between the clip at this id and the NEXT clip in order.
   *  No entry for a boundary = 'none'. */
  afterClipId: string;
  type: TransitionType;
  duration: number; // seconds
}

interface OverlayBase {
  id: string;
  /** Timeline seconds this overlay is visible for. */
  startTime: number;
  endTime: number;
  x: number; // normalized 0..1
  y: number;
  rotationDeg: number;
}

export interface TextOverlay extends OverlayBase {
  type: 'text';
  text: string;
  fontSize: number;
  color: string;
  fontFamily: string;
}

export interface StickerOverlay extends OverlayBase {
  type: 'sticker';
  emoji: string;
  scale: number;
}

export type Overlay = TextOverlay | StickerOverlay;
export type OverlayPatch = Partial<TextOverlay> & Partial<StickerOverlay>;

/** Basic keyframe architecture per spec §3 — data model only in Stage 4. A keyframe
 *  pins an overlay's position/scale/rotation/opacity at a specific timeline moment;
 *  a real interpolation/animation UI is a natural Stage 4-follow-up, not required to
 *  land this stage, but the schema is here so nothing downstream has to change. */
export interface Keyframe {
  id: string;
  overlayId: string;
  time: number; // timeline seconds
  properties: Partial<{ x: number; y: number; scale: number; opacity: number; rotationDeg: number }>;
}

export interface VideoEditState {
  clips: VideoClip[]; // array order IS timeline order
  transitions: Transition[];
  overlays: Overlay[];
  keyframes: Keyframe[];
}

export function createEmptyVideoEditState(): VideoEditState {
  return { clips: [], transitions: [], overlays: [], keyframes: [] };
}
