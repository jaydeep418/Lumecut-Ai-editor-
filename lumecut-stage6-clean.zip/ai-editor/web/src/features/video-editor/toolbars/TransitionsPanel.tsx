import type { Transition, TransitionType } from '../types';
import { clipTimelineDuration } from '../types';
import type { UseVideoEditorResult } from '../useVideoEditor';

const TYPES: Array<{ id: TransitionType; label: string }> = [
  { id: 'none', label: 'None' },
  { id: 'fade', label: 'Fade' },
];

export function TransitionsPanel({ editor }: { editor: UseVideoEditorResult }) {
  const { clips, transitions } = editor.state;

  if (clips.length < 2) {
    return (
      <div style={{ padding: 'var(--space-3) var(--space-4)' }}>
        <p style={{ fontSize: 12, color: 'var(--color-text-secondary)', margin: 0 }}>
          Import at least two clips to add a transition between them.
        </p>
      </div>
    );
  }

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--space-4)', padding: 'var(--space-3) var(--space-4)' }}>
      {clips.slice(0, -1).map((clip, index) => {
        const nextClip = clips[index + 1];
        const existing = transitions.find((t) => t.afterClipId === clip.id);
        const current: TransitionType = existing?.type ?? 'none';
        // The duration can never exceed either adjacent clip's own timeline
        // duration — editor.setTransition enforces this; this is just the
        // matching display cap for the input.
        const maxDuration = Math.max(0.1, Math.min(clipTimelineDuration(clip), clipTimelineDuration(nextClip)) - 0.2);

        return (
          <div key={clip.id} style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
            <span
              style={{
                fontSize: 11,
                color: 'var(--color-text-secondary)',
                overflow: 'hidden',
                textOverflow: 'ellipsis',
                whiteSpace: 'nowrap',
              }}
            >
              {clip.name} → {nextClip.name}
            </span>
            <div style={{ display: 'flex', alignItems: 'center', gap: 'var(--space-2)' }}>
              {TYPES.map((type) => {
                const active = current === type.id;
                return (
                  <button
                    key={type.id}
                    type="button"
                    onClick={() => editor.setTransition(clip.id, type.id, existing?.duration ?? 0.5)}
                    style={{
                      borderRadius: 'var(--radius-pill)',
                      padding: 'var(--space-1) var(--space-2)',
                      fontSize: 11,
                      cursor: 'pointer',
                      border: active ? '1px solid var(--color-accent)' : '1px solid var(--color-border)',
                      background: active ? 'var(--color-accent)' : 'var(--color-surface-raised)',
                      color: active ? '#fff' : 'var(--color-text-secondary)',
                    }}
                  >
                    {type.label}
                  </button>
                );
              })}
              {current === 'fade' && (
                <DurationInput
                  value={existing?.duration ?? 0.5}
                  max={maxDuration}
                  onChange={(duration) => editor.setTransition(clip.id, 'fade', duration)}
                />
              )}
            </div>
          </div>
        );
      })}
    </div>
  );
}

function DurationInput({
  value,
  max,
  onChange,
}: {
  value: Transition['duration'];
  max: number;
  onChange: (duration: number) => void;
}) {
  return (
    <label style={{ display: 'flex', alignItems: 'center', gap: 4, fontSize: 10, color: 'var(--color-text-secondary)' }}>
      Duration
      <input
        type="number"
        min={0.1}
        max={max}
        step={0.1}
        value={value.toFixed(1)}
        onChange={(e) => onChange(Number(e.target.value))}
        style={{
          width: 52,
          background: 'var(--color-surface-raised)',
          border: '1px solid var(--color-border)',
          borderRadius: 'var(--radius-sm)',
          color: 'var(--color-text-primary)',
          padding: '2px 4px',
          fontSize: 11,
        }}
      />
      s (max {max.toFixed(1)}s)
    </label>
  );
}
