import { useState } from 'react';
import type { TextOverlay } from '../types';
import type { UseVideoEditorResult } from '../useVideoEditor';

const TEXT_COLORS = ['#ffffff', '#000000', '#ff5c5c', '#5c9dff', '#ffd15c', '#5cff9d'];
const FONT_FAMILIES = ['sans-serif', 'serif', 'monospace', 'cursive'];

export function TextPanel({ editor }: { editor: UseVideoEditorResult }) {
  const textOverlays = editor.state.overlays.filter((o): o is TextOverlay => o.type === 'text');
  const [selectedId, setSelectedId] = useState<string | null>(textOverlays[0]?.id ?? null);
  const selected = textOverlays.find((o) => o.id === selectedId) ?? null;

  function addText() {
    const id = editor.addTextOverlay();
    setSelectedId(id);
  }

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--space-3)', padding: 'var(--space-3) var(--space-4)' }}>
      <button type="button" onClick={addText} style={addButtonStyle}>
        + Add text at playhead
      </button>

      {textOverlays.length > 0 && (
        <div style={{ display: 'flex', gap: 'var(--space-2)', overflowX: 'auto' }}>
          {textOverlays.map((overlay) => (
            <button
              key={overlay.id}
              type="button"
              onClick={() => setSelectedId(overlay.id)}
              style={{
                flex: '0 0 auto',
                padding: 'var(--space-2) var(--space-3)',
                borderRadius: 'var(--radius-pill)',
                fontSize: 12,
                border: overlay.id === selectedId ? '1px solid var(--color-accent)' : '1px solid var(--color-border)',
                background: overlay.id === selectedId ? 'var(--color-accent)' : 'var(--color-surface-raised)',
                color: overlay.id === selectedId ? '#fff' : 'var(--color-text-secondary)',
                maxWidth: 120,
                overflow: 'hidden',
                textOverflow: 'ellipsis',
                whiteSpace: 'nowrap',
              }}
            >
              {overlay.text || 'Text'}
            </button>
          ))}
        </div>
      )}

      {selected && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--space-2)' }}>
          <input
            value={selected.text}
            onChange={(e) => editor.updateOverlay(selected.id, { text: e.target.value })}
            placeholder="Text"
            style={inputStyle}
          />

          <div style={{ display: 'flex', gap: 'var(--space-2)' }}>
            {TEXT_COLORS.map((color) => (
              <button
                key={color}
                type="button"
                aria-label={`Color ${color}`}
                onClick={() => editor.updateOverlay(selected.id, { color })}
                style={{
                  width: 26,
                  height: 26,
                  borderRadius: '50%',
                  background: color,
                  border: selected.color === color ? '2px solid var(--color-accent)' : '1px solid var(--color-border)',
                  cursor: 'pointer',
                }}
              />
            ))}
          </div>

          <div style={{ display: 'flex', gap: 'var(--space-2)', overflowX: 'auto' }}>
            {FONT_FAMILIES.map((font) => (
              <button
                key={font}
                type="button"
                onClick={() => editor.updateOverlay(selected.id, { fontFamily: font })}
                style={{
                  flex: '0 0 auto',
                  padding: 'var(--space-2) var(--space-3)',
                  borderRadius: 'var(--radius-pill)',
                  fontFamily: font,
                  fontSize: 12,
                  border: selected.fontFamily === font ? '1px solid var(--color-accent)' : '1px solid var(--color-border)',
                  background: selected.fontFamily === font ? 'var(--color-accent)' : 'var(--color-surface-raised)',
                  color: selected.fontFamily === font ? '#fff' : 'var(--color-text-secondary)',
                }}
              >
                {font}
              </button>
            ))}
          </div>

          <div style={{ display: 'flex', gap: 'var(--space-2)', alignItems: 'flex-end' }}>
            <label style={numberFieldStyle}>
              Start (s)
              <input
                type="number"
                min={0}
                max={selected.endTime - 0.1}
                step={0.1}
                value={selected.startTime.toFixed(1)}
                onChange={(e) => editor.updateOverlay(selected.id, { startTime: Number(e.target.value) })}
                style={inputStyle}
              />
            </label>
            <label style={numberFieldStyle}>
              End (s)
              <input
                type="number"
                min={selected.startTime + 0.1}
                max={editor.totalDuration}
                step={0.1}
                value={selected.endTime.toFixed(1)}
                onChange={(e) => editor.updateOverlay(selected.id, { endTime: Number(e.target.value) })}
                style={inputStyle}
              />
            </label>
          </div>

          <button
            type="button"
            onClick={() => {
              editor.removeOverlay(selected.id);
              setSelectedId(null);
            }}
            style={removeButtonStyle}
          >
            Remove text
          </button>
        </div>
      )}
    </div>
  );
}

const addButtonStyle = {
  background: 'var(--color-accent)',
  color: '#fff',
  border: 'none',
  borderRadius: 'var(--radius-md)',
  padding: 'var(--space-2) var(--space-3)',
  fontSize: 13,
  fontWeight: 600,
  cursor: 'pointer',
} as const;

const inputStyle = {
  background: 'var(--color-surface-raised)',
  border: '1px solid var(--color-border)',
  borderRadius: 'var(--radius-sm)',
  color: 'var(--color-text-primary)',
  padding: 'var(--space-2) var(--space-3)',
  fontSize: 14,
  width: '100%',
} as const;

const numberFieldStyle = {
  display: 'flex',
  flexDirection: 'column',
  gap: 4,
  fontSize: 11,
  color: 'var(--color-text-secondary)',
  flex: 1,
} as const;

const removeButtonStyle = {
  background: 'transparent',
  border: '1px solid var(--color-danger)',
  color: 'var(--color-danger)',
  borderRadius: 'var(--radius-md)',
  padding: 'var(--space-2) var(--space-3)',
  fontSize: 12,
  cursor: 'pointer',
  alignSelf: 'flex-start',
} as const;
