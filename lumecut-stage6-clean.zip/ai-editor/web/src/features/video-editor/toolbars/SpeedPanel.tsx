import { SPEED_PRESETS } from '../constants';
import type { UseVideoEditorResult } from '../useVideoEditor';

interface SpeedPanelProps {
  editor: UseVideoEditorResult;
  selectedClipId: string | null;
}

export function SpeedPanel({ editor, selectedClipId }: SpeedPanelProps) {
  const clip = editor.state.clips.find((c) => c.id === selectedClipId);

  if (!clip) {
    return (
      <div style={{ padding: 'var(--space-3) var(--space-4)' }}>
        <p style={{ fontSize: 12, color: 'var(--color-text-secondary)', margin: 0 }}>
          Tap a clip on the timeline to change its speed.
        </p>
      </div>
    );
  }

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--space-3)', padding: 'var(--space-3) var(--space-4)' }}>
      <div>
        <p style={{ fontSize: 12, color: 'var(--color-text-secondary)', margin: '0 0 6px' }}>Speed</p>
        <div style={{ display: 'flex', gap: 'var(--space-2)', flexWrap: 'wrap' }}>
          {SPEED_PRESETS.map((speed) => {
            const active = clip.speed === speed;
            return (
              <button
                key={speed}
                type="button"
                onClick={() => editor.setClipSpeed(clip.id, speed)}
                style={{
                  borderRadius: 'var(--radius-pill)',
                  padding: 'var(--space-2) var(--space-3)',
                  fontSize: 12,
                  cursor: 'pointer',
                  border: active ? '1px solid var(--color-accent)' : '1px solid var(--color-border)',
                  background: active ? 'var(--color-accent)' : 'var(--color-surface-raised)',
                  color: active ? '#fff' : 'var(--color-text-secondary)',
                }}
              >
                {speed}x
              </button>
            );
          })}
        </div>
      </div>

      <button
        type="button"
        onClick={() => editor.toggleClipReversed(clip.id)}
        style={{
          alignSelf: 'flex-start',
          borderRadius: 'var(--radius-pill)',
          padding: 'var(--space-2) var(--space-3)',
          fontSize: 12,
          cursor: 'pointer',
          border: clip.reversed ? '1px solid var(--color-accent)' : '1px solid var(--color-border)',
          background: clip.reversed ? 'var(--color-accent)' : 'var(--color-surface-raised)',
          color: clip.reversed ? '#fff' : 'var(--color-text-secondary)',
        }}
      >
        {clip.reversed ? 'Reversed ✓' : 'Reverse clip'}
      </button>

      <p style={{ fontSize: 11, color: 'var(--color-text-secondary)', margin: 0 }}>
        Reverse previews via scrubbing here — the real reversed-frame render happens
        during export.
      </p>
    </div>
  );
}
