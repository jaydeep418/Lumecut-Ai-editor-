import { FILTERS } from '@/features/shared/filters';
import type { UseVideoEditorResult } from '../useVideoEditor';

interface FiltersPanelProps {
  editor: UseVideoEditorResult;
  selectedClipId: string | null;
}

export function FiltersPanel({ editor, selectedClipId }: FiltersPanelProps) {
  const clip = editor.state.clips.find((c) => c.id === selectedClipId);

  if (!clip) {
    return (
      <div style={{ padding: 'var(--space-3) var(--space-4)' }}>
        <p style={{ fontSize: 12, color: 'var(--color-text-secondary)', margin: 0 }}>
          Tap a clip on the timeline to apply a filter.
        </p>
      </div>
    );
  }

  return (
    <div style={{ display: 'flex', gap: 'var(--space-2)', padding: 'var(--space-3) var(--space-4)', overflowX: 'auto' }}>
      {FILTERS.map((filter) => {
        const active = clip.filter === filter.id;
        return (
          <button
            key={filter.id}
            type="button"
            onClick={() => editor.setClipFilter(clip.id, filter.id)}
            style={{
              flex: '0 0 auto',
              borderRadius: 'var(--radius-pill)',
              padding: 'var(--space-2) var(--space-3)',
              fontSize: 12,
              cursor: 'pointer',
              border: active ? '1px solid var(--color-accent)' : '1px solid var(--color-border)',
              background: active ? 'var(--color-accent)' : 'var(--color-surface-raised)',
              color: active ? '#fff' : 'var(--color-text-secondary)',
            }}
          >
            {filter.label}
          </button>
        );
      })}
    </div>
  );
}
