# Video Editor feature (Stage 4 — implemented)

Non-destructive edit-decision-list (EDL) video editor. No client-side re-encoding —
every clip stores in/out points into its own source file plus playback decisions
(speed, reverse, volume, filter, transform) as plain data (`types.ts`). Stage 6's
FFmpeg export pipeline reads this same schema to produce the real rendered file.

- `types.ts` — VideoClip (incl. `groupId` for non-destructive merge), Transition,
  TextOverlay/StickerOverlay, Keyframe (data model only — no keyframe interpolation
  UI yet), VideoEditState
- `timelineMath.ts` — resolves a single global timeline time into "which clip, what
  local source time" (`resolvePlayhead`) — everything else builds on this; also
  `resolveTransitionBlend()` for the Fade preview crossfade
- `useClipPlayers.ts` — one real `<video>` element per clip (never in the DOM),
  created/torn down as clips change; owns playback state exclusively
- `videoCompositor.ts` — draws the CURRENT frame of whichever video is active onto a
  canvas via `drawImage` (no manual decoding, no per-frame `getImageData`), "cover"-
  fit to the project's aspect ratio; `drawTransitionFrame()` blends two clips'
  frames for the Fade preview; `drawOverlays()` draws text/stickers on top of either
- `useVideoEditor.ts` — wires shared history (`features/shared/history.ts`),
  ProjectsContext draft-saving sync, clip players, the playback loop, every EDL
  mutation (trim/split/merge/reorder/speed/reverse/volume/mute/filter/rotate/flip/
  transitions/overlays), a deferred object-URL revocation model so Undo/Redo never
  breaks, and a `commitState()`/`latestStateRef` pattern so concurrent async
  imports (`addClip`) never overwrite each other (see PROJECT_PLAN.md's "Stage 4
  review fixes" and "Final Stage 4 fix" for why)
- `VideoCanvas.tsx` — rAF is the unconditional base redraw driver;
  `requestVideoFrameCallback` is layered on top as an accuracy booster during real
  forward playback (manual-scrub reverse/seek preview can't rely on rVFC firing
  continuously, so correctness never depends on it — see the comment in that file)
- `Timeline.tsx` — clip blocks sized by timeline duration, drag-to-scrub playhead,
  tap a clip to select it, merged clips render edge-to-edge with a 🔗 marker
- `VideoEditor.tsx` — top-level screen, composes everything below
- `toolbars/` — Edit (import/select/delete/reorder/split/trim/merge/unmerge), Audio
  (volume/mute), Speed (speed + reverse), Canvas (rotate/flip), Filters (shared
  presets), Transitions (fade/none + validated duration per boundary), Text,
  Stickers, AI (stub)

Merge is non-destructive: `mergeClips()`/`mergeWithNext()` assign a shared `groupId`
to a contiguous run of clips (each keeps its own source/trim/speed/etc.), clearing
any transition between merged members; `unmergeGroup()` reverses it. Fade actually
crossfades in the preview now (a same-timeline-length approximation — see
`resolveTransitionBlend`'s doc comment for why real timeline-overlap crossfade is
Stage 6's job, not this one's).

Reverse playback previews via manual scrubbing (HTML5 video has no reliable native
reverse) — the real reversed-frame render happens in Stage 6. Splitting a reversed
clip correctly flips which half gets which in/out range (reversed plays outPoint→
inPoint, so timeline-order and source-order are inverted relative to a forward clip).
AI-dependent tools (auto captions, subtitles, AI video effects, script/caption
generation) are real UI wired to `features/ai/videoAiService.ts`'s interface,
stubbed until Stage 5.

Draft saving: the EDL lives in `ProjectsContext` (still in-memory/session-only, same
Stage 2 rule) so it survives navigating away and back — see that file's
`getVideoEditState`/`setVideoEditState`.
