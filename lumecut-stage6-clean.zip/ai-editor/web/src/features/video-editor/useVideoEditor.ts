import { useEffect, useRef, useState } from 'react';
import { useHistoryState } from '@/features/shared/history';
import { useProjects } from '@/state/ProjectsContext';
import type { Project } from '@types/project';
import { probeVideoDuration } from './probeVideo';
import { useClipPlayers } from './useClipPlayers';
import {
  computeTotalTimelineDuration,
  resolvePlayhead,
  resolveTransitionBlend,
  type PlayheadResolution,
  type TransitionBlend,
} from './timelineMath';
import {
  clipTimelineDuration,
  createClipFromFile,
  createEmptyVideoEditState,
  type Overlay,
  type OverlayPatch,
  type StickerOverlay,
  type TextOverlay,
  type TransitionType,
  type VideoClip,
  type VideoEditState,
} from './types';

const MIN_CLIP_DURATION = 0.2; // seconds — floor so trim/split can't produce a zero-length clip
const MIN_TRANSITION_DURATION = 0.1;

function clampPlaybackRate(speed: number): number {
  return Math.min(16, Math.max(0.0625, speed));
}

export function useVideoEditor(project: Project) {
  const projects = useProjects();
  const [loading, setLoading] = useState(true);

  const history = useHistoryState<VideoEditState>(
    projects.getVideoEditState(project.id) ?? createEmptyVideoEditState()
  );
  const { state } = history;

  // --- Latest-state ref + commit wrapper (fix: async addClip stale-state race) ---
  // `state` here is a snapshot from whatever render captured this closure. An
  // async function (addClip) that reads `state` before an `await` and commits
  // after it can silently overwrite a DIFFERENT concurrent import that committed
  // in between — both would compute their new clips array from the SAME stale
  // snapshot. `latestStateRef` fixes this by being updated SYNCHRONOUSLY at the
  // moment of every commit (via `commitState` below), not just on each render —
  // so even two `addClip` calls resolving back-to-back (before React has had a
  // chance to re-render this hook) still see each other's results. The plain
  // render-time assignment further below covers state changes from other sources
  // (undo/redo, the initial draft restore) as a fallback.
  const latestStateRef = useRef(state);
  latestStateRef.current = state;

  function commitState(next: VideoEditState) {
    latestStateRef.current = next;
    history.commit(next);
  }

  // --- Object URL lifecycle (fix: never revoke a URL undo/redo might still need) ---
  // The undo/redo stack lives entirely inside useHistoryState's refs, local to this
  // mounted hook instance — a committed state that no longer lists a clip can still
  // be sitting in that stack, reachable by Undo. So NO individual mutation (removeClip,
  // splitAtPlayhead, etc.) ever revokes a clip's sourceUrl directly. Instead: every
  // URL this instance has ever used is tracked here, and only the ones NOT in the
  // final state get revoked, once, on unmount — at which point the local undo stack
  // is gone too, so nothing could still reference them. Project deletion (a separate,
  // final action) revokes whatever's left in the saved draft — see ProjectsContext.
  const usedUrlsRef = useRef<Set<string>>(new Set());

  useEffect(() => {
    for (const clip of state.clips) {
      usedUrlsRef.current.add(clip.sourceUrl);
    }
  }, [state.clips]);

  useEffect(() => {
    return () => {
      const stillUsed = new Set(latestStateRef.current.clips.map((c) => c.sourceUrl));
      for (const url of usedUrlsRef.current) {
        if (!stillUsed.has(url)) {
          URL.revokeObjectURL(url);
        }
      }
    };
    // Runs once, on unmount only — intentionally not re-triggered per edit.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Seed the very first clip from the project's original file, exactly once, only
  // for a project that has never been edited before (no saved draft in
  // ProjectsContext yet). Draft restoration is handled by the useHistoryState
  // initializer above — this effect only runs for a genuinely fresh project.
  useEffect(() => {
    if (projects.getVideoEditState(project.id)) {
      setLoading(false);
      return;
    }
    let cancelled = false;
    probeVideoDuration(project.previewUrl)
      .then((duration) => {
        if (cancelled) return;
        const clip = createClipFromFile(project.previewUrl, project.name);
        clip.sourceDuration = duration;
        clip.outPoint = duration;
        commitState({ ...createEmptyVideoEditState(), clips: [clip] });
        setLoading(false);
      })
      .catch(() => {
        if (!cancelled) setLoading(false);
      });
    return () => {
      cancelled = true;
    };
    // Intentionally run once per mounted editor instance (the editor route remounts
    // per project id — see pages/EditorPlaceholder.tsx's `key={project.id}`).
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Draft saving: push every committed change back into ProjectsContext so it
  // survives navigating away and back within this session (Stage 9 replaces the
  // underlying storage, not this call site).
  useEffect(() => {
    projects.setVideoEditState(project.id, state);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [state]);

  function handleMetadataLoaded(clipId: string, duration: number) {
    commitState({
      ...state,
      clips: state.clips.map((c) =>
        c.id === clipId ? { ...c, sourceDuration: duration, outPoint: c.outPoint === 0 ? duration : c.outPoint } : c
      ),
    });
  }

  const clipPlayers = useClipPlayers(state.clips, handleMetadataLoaded);

  // --- Playback ---
  const totalDuration = computeTotalTimelineDuration(state.clips);
  const timelineTimeRef = useRef(0);
  const [timelineTime, setTimelineTime] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const rafRef = useRef<number | null>(null);
  const lastTsRef = useRef<number | null>(null);

  function pauseAllExcept(...activeIds: Array<string | undefined>) {
    const keep = new Set(activeIds.filter((id): id is string => Boolean(id)));
    for (const clip of state.clips) {
      if (keep.has(clip.id)) continue;
      const video = clipPlayers.getPlayer(clip.id);
      if (video && !video.paused) video.pause();
    }
  }

  function seekClipTo(resolution: PlayheadResolution) {
    const video = clipPlayers.getPlayer(resolution.clip.id);
    if (!video) return;
    video.volume = resolution.clip.muted ? 0 : resolution.clip.volume;
    if (Math.abs(video.currentTime - resolution.sourceTime) > 0.03) {
      video.currentTime = resolution.sourceTime;
    }
  }

  /** Preps the INCOMING clip of an active fade transition: paused, seeked to its
   *  own starting frame, silent (preview-only crossfade — Stage 6 handles real
   *  audio crossfade). */
  function primeTransitionTarget(blend: TransitionBlend) {
    const toVideo = clipPlayers.getPlayer(blend.toClip.id);
    if (!toVideo) return;
    toVideo.volume = 0;
    if (!toVideo.paused) toVideo.pause();
    const targetTime = blend.toClip.reversed ? blend.toClip.outPoint : blend.toClip.inPoint;
    if (Math.abs(toVideo.currentTime - targetTime) > 0.03) {
      toVideo.currentTime = targetTime;
    }
  }

  /** Called every rAF tick while playing — the only place that starts/stops a video
   *  element's OWN playback (as opposed to `seek`, which just repositions). */
  function syncPlayingClip(resolution: PlayheadResolution | null, blend: TransitionBlend | null) {
    pauseAllExcept(resolution?.clip.id, blend?.toClip.id);
    if (!resolution) return;
    const video = clipPlayers.getPlayer(resolution.clip.id);
    if (!video) return;
    video.volume = resolution.clip.muted ? 0 : resolution.clip.volume;

    if (resolution.clip.reversed) {
      // HTML5 video has no reliable native reverse playback — preview it by
      // scrubbing currentTime manually every tick instead of calling .play().
      // The real reverse RENDER happens in Stage 6.
      if (!video.paused) video.pause();
      if (Math.abs(video.currentTime - resolution.sourceTime) > 0.03) {
        video.currentTime = resolution.sourceTime;
      }
    } else {
      video.playbackRate = clampPlaybackRate(resolution.clip.speed);
      if (video.paused) {
        if (Math.abs(video.currentTime - resolution.sourceTime) > 0.1) {
          video.currentTime = resolution.sourceTime;
        }
        video.play().catch(() => {});
      } else if (Math.abs(video.currentTime - resolution.sourceTime) > 0.2) {
        video.currentTime = resolution.sourceTime; // drift correction
      }
    }

    if (blend) primeTransitionTarget(blend);
  }

  useEffect(() => {
    if (!isPlaying) {
      lastTsRef.current = null;
      if (rafRef.current !== null) cancelAnimationFrame(rafRef.current);
      // Cancelling OUR rAF loop does not itself stop the browser's own video
      // playback — without this, audio/video from the active clip would keep
      // going after Pause.
      for (const clip of state.clips) {
        clipPlayers.getPlayer(clip.id)?.pause();
      }
      return;
    }

    function tick(ts: number) {
      if (lastTsRef.current === null) lastTsRef.current = ts;
      const deltaSeconds = (ts - lastTsRef.current) / 1000;
      lastTsRef.current = ts;

      let next = timelineTimeRef.current + deltaSeconds;
      if (next >= totalDuration) {
        next = totalDuration;
        timelineTimeRef.current = next;
        setTimelineTime(next);
        setIsPlaying(false);
        return;
      }

      timelineTimeRef.current = next;
      setTimelineTime(next);
      syncPlayingClip(resolvePlayhead(state.clips, next), resolveTransitionBlend(state.clips, state.transitions, next));
      rafRef.current = requestAnimationFrame(tick);
    }

    rafRef.current = requestAnimationFrame(tick);
    return () => {
      if (rafRef.current !== null) cancelAnimationFrame(rafRef.current);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isPlaying, state.clips, state.transitions, totalDuration]);

  function play() {
    if (state.clips.length === 0) return;
    if (timelineTimeRef.current >= totalDuration) {
      timelineTimeRef.current = 0;
      setTimelineTime(0);
    }

    // Kick off the active clip's playback SYNCHRONOUSLY, within this function's own
    // call stack — mobile browsers (notably iOS Safari) require .play() to
    // originate directly from a user gesture for audio-enabled playback to be
    // allowed. Deferring the first call to a later requestAnimationFrame tick (as
    // the rAF loop otherwise would) can silently fail there. The rAF loop still
    // owns ongoing sync/drift-correction/clip-boundary transitions once playback
    // is underway — this just makes sure the FIRST call rides the gesture.
    const resolution = resolvePlayhead(state.clips, timelineTimeRef.current);
    if (resolution && !resolution.clip.reversed) {
      const video = clipPlayers.getPlayer(resolution.clip.id);
      if (video) {
        video.volume = resolution.clip.muted ? 0 : resolution.clip.volume;
        video.playbackRate = clampPlaybackRate(resolution.clip.speed);
        if (Math.abs(video.currentTime - resolution.sourceTime) > 0.05) {
          video.currentTime = resolution.sourceTime;
        }
        video.play().catch((err) => {
          // Autoplay/gesture policies can still reject this in some contexts —
          // fail soft. The rAF loop's own sync will keep retrying via its regular
          // play() call each tick, and manual scrubbing still works regardless.
          console.warn('Video playback could not start:', err);
        });
      }
    }

    setIsPlaying(true);
  }

  function pause() {
    setIsPlaying(false);
    // Immediate feedback rather than waiting for the isPlaying effect to react.
    const resolution = resolvePlayhead(state.clips, timelineTimeRef.current);
    if (resolution) clipPlayers.getPlayer(resolution.clip.id)?.pause();
  }

  function seek(time: number) {
    const clamped = Math.min(totalDuration, Math.max(0, time));
    timelineTimeRef.current = clamped;
    setTimelineTime(clamped);
    const resolution = resolvePlayhead(state.clips, clamped);
    const blend = resolveTransitionBlend(state.clips, state.transitions, clamped);
    pauseAllExcept(undefined);
    if (resolution) seekClipTo(resolution);
    if (blend) primeTransitionTarget(blend);
  }

  const activePlayhead = resolvePlayhead(state.clips, timelineTime);
  const transitionBlend = resolveTransitionBlend(state.clips, state.transitions, timelineTime);

  // --- EDL mutations ---
  function updateClip(id: string, patch: Partial<VideoClip>) {
    commitState({ ...state, clips: state.clips.map((c) => (c.id === id ? { ...c, ...patch } : c)) });
  }

  /**
   * Imports a new clip. Async (must probe the file's duration before it can enter
   * the EDL with a correct outPoint — see probeVideoDuration), which means several
   * calls can be in flight at once if the user picks multiple files quickly.
   *
   * Insertion policy (deterministic, documented): each import is appended to the
   * timeline in the order its OWN probe resolves — not the order the user started
   * the imports in, and not the stale pre-await snapshot of `state`. Reading
   * `latestStateRef.current` (rather than the `state` this closure captured when
   * addClip was called) is what makes this safe: that ref is updated
   * SYNCHRONOUSLY by `commitState` at the moment of every commit, so even two
   * imports resolving back-to-back — before React has re-rendered this hook —
   * each still see the other's result and append after it, rather than both
   * computing their new clips array from the same stale array and one silently
   * overwriting the other.
   */
  async function addClip(file: File) {
    const url = URL.createObjectURL(file);
    const duration = await probeVideoDuration(url).catch(() => 0);
    const clip = createClipFromFile(url, file.name);
    clip.sourceDuration = duration;
    clip.outPoint = duration;
    const base = latestStateRef.current;
    commitState({ ...base, clips: [...base.clips, clip] });
    return clip.id;
  }

  function removeClip(id: string) {
    const toRemove = state.clips.find((c) => c.id === id);
    let nextClips = state.clips.filter((c) => c.id !== id);

    // If removing this clip leaves exactly one other member in its merge group,
    // a "group" of one is meaningless — clear it so the UI doesn't show a lone
    // clip as still merged with something that no longer exists.
    if (toRemove?.groupId) {
      const remaining = nextClips.filter((c) => c.groupId === toRemove.groupId);
      if (remaining.length === 1) {
        nextClips = nextClips.map((c) => (c.id === remaining[0].id ? { ...c, groupId: null } : c));
      }
    }

    // NOTE: sourceUrl is deliberately NOT revoked here — see the URL lifecycle
    // comment near the top of this hook. Undo can restore this exact clip.
    commitState({
      ...state,
      clips: nextClips,
      transitions: state.transitions.filter((t) => t.afterClipId !== id),
    });
  }

  function moveClip(id: string, direction: 'left' | 'right') {
    const index = state.clips.findIndex((c) => c.id === id);
    if (index === -1) return;
    const targetIndex = direction === 'left' ? index - 1 : index + 1;
    if (targetIndex < 0 || targetIndex >= state.clips.length) return;
    const next = [...state.clips];
    [next[index], next[targetIndex]] = [next[targetIndex], next[index]];
    commitState({ ...state, clips: next });
  }

  /** Splits the clip currently under the playhead into two clips at that point.
   *  Both results always satisfy outPoint > inPoint and preserve `reversed`. */
  function splitAtPlayhead() {
    const resolution = activePlayhead;
    if (!resolution) return;
    const { clip, sourceTime, clipIndex } = resolution;
    if (sourceTime <= clip.inPoint + MIN_CLIP_DURATION || sourceTime >= clip.outPoint - MIN_CLIP_DURATION) {
      return; // too close to an edge to make two meaningful clips
    }

    let first: VideoClip;
    let second: VideoClip;
    if (clip.reversed) {
      // Reversed playback runs from outPoint DOWN to inPoint, so the piece that
      // plays FIRST on the timeline is the one covering [sourceTime, outPoint] —
      // the opposite pairing from a forward clip. Both keep reversed: true and
      // both satisfy outPoint > inPoint because sourceTime is strictly between
      // clip.inPoint and clip.outPoint (guarded above).
      first = { ...clip, inPoint: sourceTime };
      second = { ...clip, id: crypto.randomUUID(), outPoint: sourceTime };
    } else {
      first = { ...clip, outPoint: sourceTime };
      second = { ...clip, id: crypto.randomUUID(), inPoint: sourceTime };
    }

    // A split clip is no longer a single unit — clear any merge grouping so the
    // two pieces don't silently render as still-merged with each other.
    first = { ...first, groupId: null };
    second = { ...second, groupId: null };

    const nextClips = [...state.clips];
    nextClips.splice(clipIndex, 1, first, second);
    // The original clip's own transition-after (if any) belongs to whichever half
    // now sits last — `second`, since `first` is a new internal boundary.
    const nextTransitions = state.transitions.map((t) => (t.afterClipId === clip.id ? { ...t, afterClipId: second.id } : t));
    commitState({ ...state, clips: nextClips, transitions: nextTransitions });
  }

  function trimClip(id: string, inPoint: number, outPoint: number) {
    const clip = state.clips.find((c) => c.id === id);
    if (!clip) return;
    const clampedIn = Math.max(0, Math.min(inPoint, clip.sourceDuration - MIN_CLIP_DURATION));
    const clampedOut = Math.min(clip.sourceDuration, Math.max(outPoint, clampedIn + MIN_CLIP_DURATION));
    updateClip(id, { inPoint: clampedIn, outPoint: clampedOut });
  }

  function setClipSpeed(id: string, speed: number) {
    updateClip(id, { speed });
  }

  function toggleClipReversed(id: string) {
    const clip = state.clips.find((c) => c.id === id);
    if (clip) updateClip(id, { reversed: !clip.reversed });
  }

  function setClipVolume(id: string, volume: number) {
    updateClip(id, { volume });
  }

  function toggleClipMuted(id: string) {
    const clip = state.clips.find((c) => c.id === id);
    if (clip) updateClip(id, { muted: !clip.muted });
  }

  function setClipFilter(id: string, filter: VideoClip['filter']) {
    updateClip(id, { filter });
  }

  function rotateClip90(id: string) {
    const clip = state.clips.find((c) => c.id === id);
    if (clip) updateClip(id, { rotationDeg: ((clip.rotationDeg + 90) % 360) as 0 | 90 | 180 | 270 });
  }

  function flipClipHorizontal(id: string) {
    const clip = state.clips.find((c) => c.id === id);
    if (clip) updateClip(id, { flipHorizontal: !clip.flipHorizontal });
  }

  function flipClipVertical(id: string) {
    const clip = state.clips.find((c) => c.id === id);
    if (clip) updateClip(id, { flipVertical: !clip.flipVertical });
  }

  /** Non-destructive merge: assigns a shared groupId to a CONTIGUOUS run of clips,
   *  presenting them as one unit (no internal transitions) while every clip keeps
   *  its own sourceUrl/inPoint/outPoint/edit decisions — no re-encoding, nothing
   *  physically combined. Stage 6's renderer can treat consecutive same-groupId
   *  clips as one deterministic concatenated segment. */
  function mergeClips(clipIds: string[]) {
    if (clipIds.length < 2) return;
    const indices = clipIds.map((id) => state.clips.findIndex((c) => c.id === id));
    if (indices.some((i) => i === -1)) return;

    const sorted = [...indices].sort((a, b) => a - b);
    for (let i = 1; i < sorted.length; i++) {
      if (sorted[i] !== sorted[i - 1] + 1) return; // must be contiguous for a deterministic merge
    }

    const memberIds = new Set(clipIds);
    const existingGroupId = state.clips.find((c) => memberIds.has(c.id) && c.groupId)?.groupId;
    const groupId = existingGroupId ?? crypto.randomUUID();
    const nextClips = state.clips.map((c) => (memberIds.has(c.id) ? { ...c, groupId } : c));

    // Internal boundaries within the merged run no longer show a transition —
    // it's presented as one continuous unit. Boundaries to clips OUTSIDE the
    // group are untouched.
    const internalBoundaryIds = new Set(sorted.slice(0, -1).map((i) => state.clips[i].id));
    const nextTransitions = state.transitions.filter((t) => !internalBoundaryIds.has(t.afterClipId));

    commitState({ ...state, clips: nextClips, transitions: nextTransitions });
  }

  function mergeWithNext(clipId: string) {
    const index = state.clips.findIndex((c) => c.id === clipId);
    if (index === -1 || index + 1 >= state.clips.length) return;
    mergeClips([state.clips[index].id, state.clips[index + 1].id]);
  }

  function unmergeGroup(groupId: string) {
    commitState({
      ...state,
      clips: state.clips.map((c) => (c.groupId === groupId ? { ...c, groupId: null } : c)),
    });
  }

  function setTransition(afterClipId: string, type: TransitionType, duration = 0.5) {
    const clipIndex = state.clips.findIndex((c) => c.id === afterClipId);
    const fromClip = clipIndex !== -1 ? state.clips[clipIndex] : undefined;
    const toClip = clipIndex !== -1 ? state.clips[clipIndex + 1] : undefined;

    // Validate: a transition can never last longer than either adjacent clip's
    // own timeline duration (it plays out within the outgoing clip's last
    // `duration` seconds — see resolveTransitionBlend), and never below a sane
    // minimum for 'fade'.
    let validatedDuration = Math.max(MIN_TRANSITION_DURATION, duration);
    if (fromClip && toClip) {
      const maxAllowed = Math.max(
        MIN_TRANSITION_DURATION,
        Math.min(clipTimelineDuration(fromClip), clipTimelineDuration(toClip)) - MIN_CLIP_DURATION
      );
      validatedDuration = Math.min(validatedDuration, maxAllowed);
    }

    const existingIndex = state.transitions.findIndex((t) => t.afterClipId === afterClipId);
    const next = [...state.transitions];
    if (type === 'none') {
      if (existingIndex !== -1) next.splice(existingIndex, 1);
    } else if (existingIndex !== -1) {
      next[existingIndex] = { afterClipId, type, duration: validatedDuration };
    } else {
      next.push({ afterClipId, type, duration: validatedDuration });
    }
    commitState({ ...state, transitions: next });
  }

  // --- Overlays (text/stickers) ---
  function addTextOverlay(): string {
    const overlay: TextOverlay = {
      id: crypto.randomUUID(),
      type: 'text',
      text: 'Tap to edit',
      x: 0.5,
      y: 0.5,
      rotationDeg: 0,
      fontSize: 60,
      color: '#ffffff',
      fontFamily: 'sans-serif',
      startTime: timelineTime,
      endTime: Math.min(totalDuration, timelineTime + 3),
    };
    commitState({ ...state, overlays: [...state.overlays, overlay] });
    return overlay.id;
  }

  function addStickerOverlay(emoji: string): string {
    const overlay: StickerOverlay = {
      id: crypto.randomUUID(),
      type: 'sticker',
      emoji,
      x: 0.5,
      y: 0.5,
      rotationDeg: 0,
      scale: 1,
      startTime: timelineTime,
      endTime: Math.min(totalDuration, timelineTime + 3),
    };
    commitState({ ...state, overlays: [...state.overlays, overlay] });
    return overlay.id;
  }

  function updateOverlay(id: string, patch: OverlayPatch) {
    commitState({
      ...state,
      overlays: state.overlays.map((o) => (o.id === id ? ({ ...o, ...patch } as Overlay) : o)),
    });
  }

  function previewOverlayPosition(id: string, x: number, y: number) {
    history.setLive({ ...state, overlays: state.overlays.map((o) => (o.id === id ? { ...o, x, y } : o)) });
  }

  function removeOverlay(id: string) {
    commitState({ ...state, overlays: state.overlays.filter((o) => o.id !== id) });
  }

  return {
    state,
    loading,
    totalDuration,
    timelineTime,
    isPlaying,
    activePlayhead,
    transitionBlend,
    getPlayer: clipPlayers.getPlayer,
    play,
    pause,
    seek,
    canUndo: history.canUndo,
    canRedo: history.canRedo,
    undo: history.undo,
    redo: history.redo,
    addClip,
    removeClip,
    moveClip,
    splitAtPlayhead,
    trimClip,
    setClipSpeed,
    toggleClipReversed,
    setClipVolume,
    toggleClipMuted,
    setClipFilter,
    rotateClip90,
    flipClipHorizontal,
    flipClipVertical,
    mergeClips,
    mergeWithNext,
    unmergeGroup,
    setTransition,
    addTextOverlay,
    addStickerOverlay,
    updateOverlay,
    previewOverlayPosition,
    removeOverlay,
  };
}

export type UseVideoEditorResult = ReturnType<typeof useVideoEditor>;
