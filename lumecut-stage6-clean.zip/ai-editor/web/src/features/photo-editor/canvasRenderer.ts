import { getFilterDefinition } from '@/features/shared/filters';
import type { Adjustments, CropRect, DrawingStroke, PhotoEditState } from './types';

/** Caps the working canvas size so editing stays smooth on large source photos.
 *  Full-resolution rendering for the actual exported file is Stage 6's job — this
 *  state model reproduces the same result at any resolution, so nothing is lost. */
const MAX_WORKING_DIMENSION = 1600;

export interface LoadedImage {
  element: HTMLImageElement;
  width: number;
  height: number;
}

export function loadImage(url: string): Promise<LoadedImage> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => resolve({ element: img, width: img.naturalWidth, height: img.naturalHeight });
    img.onerror = () => reject(new Error(`Failed to load image: ${url}`));
    img.src = url;
  });
}

function buildAdjustmentFilterString(a: Adjustments): string {
  // brightness/exposure both push the same native `brightness()` filter — they're
  // kept as separate sliders (per spec) but combined here since Canvas 2D only
  // exposes one brightness axis; weighting them differently keeps each slider
  // visibly distinct without needing a custom pixel-level exposure curve.
  const brightnessPct = 1 + (a.brightness / 100) * 0.5 + (a.exposure / 100) * 0.9;
  const contrastPct = 1 + (a.contrast / 100) * 0.6;
  const saturatePct = 1 + (a.saturation / 100) * 0.8;
  const blurPx = Math.max(0, a.blur) * 0.15;

  return [
    `brightness(${Math.max(0, brightnessPct).toFixed(3)})`,
    `contrast(${Math.max(0, contrastPct).toFixed(3)})`,
    `saturate(${Math.max(0, saturatePct).toFixed(3)})`,
    blurPx > 0 ? `blur(${blurPx.toFixed(2)}px)` : '',
  ]
    .filter(Boolean)
    .join(' ');
}

function computeCroppedSourceRect(image: LoadedImage, crop: CropRect | null) {
  if (!crop) return { sx: 0, sy: 0, sw: image.width, sh: image.height };
  return {
    sx: crop.x * image.width,
    sy: crop.y * image.height,
    sw: crop.width * image.width,
    sh: crop.height * image.height,
  };
}

function computeOutputSize(sw: number, sh: number, rotationDeg: number, targetMaxDimension: number | null) {
  const rotated = rotationDeg === 90 || rotationDeg === 270;
  const naturalW = rotated ? sh : sw;
  const naturalH = rotated ? sw : sh;
  const cap = targetMaxDimension ? Math.min(targetMaxDimension, MAX_WORKING_DIMENSION) : MAX_WORKING_DIMENSION;
  const scale = Math.min(1, cap / Math.max(naturalW, naturalH));
  return { width: Math.max(1, Math.round(naturalW * scale)), height: Math.max(1, Math.round(naturalH * scale)) };
}

/**
 * Renders `state` onto `canvas` starting from the original, untouched `image`.
 * Safe to call on every state change: it's a clear plus a handful of native,
 * browser-composited draw calls. The one potentially expensive step (sharpen) only
 * runs when sharpness is actually turned on — the common case pays nothing for it.
 */
export function renderPhotoEdit(
  canvas: HTMLCanvasElement,
  image: LoadedImage,
  state: PhotoEditState,
  options?: { draftStroke?: DrawingStroke; exactOutputSize?: { width: number; height: number } }
): void {
  const ctx = canvas.getContext('2d');
  if (!ctx) return;

  const { sx, sy, sw, sh } = computeCroppedSourceRect(image, state.transform.crop);
  // Export (Stage 6) passes exactOutputSize to render at the true requested
  // resolution — bypassing MAX_WORKING_DIMENSION entirely, which exists only to
  // keep live EDITING smooth, not to cap what the final exported file can be.
  const { width, height } =
    options?.exactOutputSize ?? computeOutputSize(sw, sh, state.transform.rotationDeg, state.transform.targetMaxDimension);

  if (canvas.width !== width || canvas.height !== height) {
    canvas.width = width;
    canvas.height = height;
  }

  ctx.save();
  ctx.clearRect(0, 0, width, height);

  // --- base image: rotate/flip/crop, adjustments + filter preset in one draw ---
  ctx.translate(width / 2, height / 2);
  ctx.rotate((state.transform.rotationDeg * Math.PI) / 180);
  ctx.scale(state.transform.flipHorizontal ? -1 : 1, state.transform.flipVertical ? -1 : 1);

  const rotated = state.transform.rotationDeg === 90 || state.transform.rotationDeg === 270;
  const drawW = rotated ? height : width;
  const drawH = rotated ? width : height;

  const filterDef = getFilterDefinition(state.filter);
  const adjustmentFilter = buildAdjustmentFilterString(state.adjustments);
  ctx.filter =
    [adjustmentFilter, filterDef.cssFilter !== 'none' ? filterDef.cssFilter : ''].filter(Boolean).join(' ') || 'none';

  ctx.drawImage(image.element, sx, sy, sw, sh, -drawW / 2, -drawH / 2, drawW, drawH);
  ctx.restore(); // also resets ctx.filter for the overlay/layer draws below

  // --- filter preset color overlay, for looks a CSS filter alone can't reach ---
  if (filterDef.overlay) {
    ctx.save();
    ctx.globalCompositeOperation = filterDef.overlay.composite;
    ctx.globalAlpha = filterDef.overlay.opacity;
    ctx.fillStyle = filterDef.overlay.color;
    ctx.fillRect(0, 0, width, height);
    ctx.restore();
  }

  // --- temperature: warm/cool tint overlay ---
  if (state.adjustments.temperature !== 0) {
    const warm = state.adjustments.temperature > 0;
    ctx.save();
    ctx.globalCompositeOperation = 'overlay';
    ctx.globalAlpha = Math.min(0.35, (Math.abs(state.adjustments.temperature) / 100) * 0.35);
    ctx.fillStyle = warm ? '#ff9d3b' : '#3b6bff';
    ctx.fillRect(0, 0, width, height);
    ctx.restore();
  }

  // --- sharpen: the only step that touches raw pixel data, gated behind actual use ---
  if (state.adjustments.sharpness > 0) {
    applySharpen(ctx, width, height, state.adjustments.sharpness / 100);
  }

  // --- freehand drawing strokes (committed + one optional in-progress draft) ---
  const strokesToDraw = options?.draftStroke ? [...state.strokes, options.draftStroke] : state.strokes;
  for (const stroke of strokesToDraw) {
    if (stroke.points.length < 2) continue;
    ctx.save();
    ctx.strokeStyle = stroke.color;
    ctx.lineWidth = (stroke.size / 1000) * width;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    ctx.beginPath();
    ctx.moveTo(stroke.points[0].x * width, stroke.points[0].y * height);
    for (const point of stroke.points.slice(1)) {
      ctx.lineTo(point.x * width, point.y * height);
    }
    ctx.stroke();
    ctx.restore();
  }

  // --- text & sticker layers, drawn in insertion order (later = on top) ---
  for (const layer of state.layers) {
    ctx.save();
    ctx.translate(layer.x * width, layer.y * height);
    ctx.rotate((layer.rotationDeg * Math.PI) / 180);
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    if (layer.type === 'sticker') {
      const size = (layer.scale * width) / 8;
      ctx.font = `${size}px sans-serif`;
      ctx.fillText(layer.emoji, 0, 0);
    } else {
      const fontSize = (layer.fontSize / 1000) * width;
      ctx.font = `${fontSize}px ${layer.fontFamily}`;
      ctx.fillStyle = layer.color;
      ctx.fillText(layer.text, 0, 0);
    }
    ctx.restore();
  }
}

/** Simple 3x3 unsharp-style convolution. Only ever called when sharpness > 0. */
function applySharpen(ctx: CanvasRenderingContext2D, width: number, height: number, amount: number) {
  const imageData = ctx.getImageData(0, 0, width, height);
  const src = imageData.data;
  const out = new Uint8ClampedArray(src.length);
  const center = 1 + 4 * amount;
  const edge = -amount;

  for (let y = 0; y < height; y++) {
    for (let x = 0; x < width; x++) {
      const i = (y * width + x) * 4;
      for (let c = 0; c < 3; c++) {
        const sample = (dx: number, dy: number) => {
          const xx = Math.min(width - 1, Math.max(0, x + dx));
          const yy = Math.min(height - 1, Math.max(0, y + dy));
          return src[(yy * width + xx) * 4 + c];
        };
        out[i + c] = center * sample(0, 0) + edge * (sample(-1, 0) + sample(1, 0) + sample(0, -1) + sample(0, 1));
      }
      out[i + 3] = src[i + 3];
    }
  }
  imageData.data.set(out);
  ctx.putImageData(imageData, 0, 0);
}
