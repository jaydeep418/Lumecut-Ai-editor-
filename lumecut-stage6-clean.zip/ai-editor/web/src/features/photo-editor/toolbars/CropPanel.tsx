import { ASPECT_RATIOS } from '@/constants/aspectRatios';
import type { AspectRatioId } from '@types/project';
import type { UsePhotoEditorResult } from '../usePhotoEditor';

interface CropPanelProps {
  editor: UsePhotoEditorResult;
  lockedRatioId: AspectRatioId | 'free';
  onSelectRatio: (id: AspectRatioId | 'free') => void;
  onApply: () => void;
  onCancel: () => void;
}

const RESIZE_PRESETS: Array<{ label: string; value: number | null }> = [
  { label: 'Original', value: null },
  { label: '1920px', value: 1920 },
  { label: '1280px', value: 1280 },
  { label: '720px', value: 720 },
];

export function CropPanel({ editor, lockedRatioId, onSelectRatio, onApply, onCancel }: CropPanelProps) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--space-4)', padding: 'var(--space-3) var(--space-4)' }}>
      <div>
        <p style={sectionLabelStyle}>Aspect ratio</p>
        <div style={{ display: 'flex', gap: 'var(--space-2)', flexWrap: 'wrap' }}>
          <RatioChip label="Free" active={lockedRatioId === 'free'} onClick={() => onSelectRatio('free')} />
          {ASPECT_RATIOS.map((ratio) => (
            <RatioChip
              key={ratio.id}
              label={ratio.label}
              active={lockedRatioId === ratio.id}
              onClick={() => onSelectRatio(ratio.id)}
            />
          ))}
        </div>
      </div>

      <div>
        <p style={sectionLabelStyle}>Rotate & flip</p>
        <div style={{ display: 'flex', gap: 'var(--space-2)' }}>
          <ActionChip label="Rotate 90°" onClick={editor.rotate90} />
          <ActionChip label="Flip H" onClick={editor.flipHorizontal} />
          <ActionChip label="Flip V" onClick={editor.flipVertical} />
        </div>
      </div>

      <div>
        <p style={sectionLabelStyle}>Resize (max dimension)</p>
        <div style={{ display: 'flex', gap: 'var(--space-2)', flexWrap: 'wrap' }}>
          {RESIZE_PRESETS.map((preset) => (
            <RatioChip
              key={preset.label}
              label={preset.label}
              active={editor.state.transform.targetMaxDimension === preset.value}
              onClick={() => editor.setTargetMaxDimension(preset.value)}
            />
          ))}
        </div>
      </div>

      <div style={{ display: 'flex', gap: 'var(--space-2)', justifyContent: 'flex-end' }}>
        <button type="button" onClick={onCancel} style={secondaryButtonStyle}>
          Cancel
        </button>
        <button type="button" onClick={onApply} style={primaryButtonStyle}>
          Apply Crop
        </button>
      </div>
    </div>
  );
}

function RatioChip({ label, active, onClick }: { label: string; active: boolean; onClick: () => void }) {
  return (
    <button
      type="button"
      onClick={onClick}
      style={{
        borderRadius: 'var(--radius-pill)',
        padding: 'var(--space-2) var(--space-3)',
        fontSize: 12,
        cursor: 'pointer',
        border: active ? '1px solid var(--color-accent)' : '1px solid var(--color-border)',
        background: active ? 'var(--color-accent)' : 'var(--color-surface-raised)',
        color: active ? '#fff' : 'var(--color-text-secondary)',
      }}
    >
      {label}
    </button>
  );
}

function ActionChip({ label, onClick }: { label: string; onClick: () => void }) {
  return (
    <button
      type="button"
      onClick={onClick}
      style={{
        borderRadius: 'var(--radius-pill)',
        padding: 'var(--space-2) var(--space-3)',
        fontSize: 12,
        cursor: 'pointer',
        border: '1px solid var(--color-border)',
        background: 'var(--color-surface-raised)',
        color: 'var(--color-text-primary)',
      }}
    >
      {label}
    </button>
  );
}

const sectionLabelStyle = { fontSize: 12, color: 'var(--color-text-secondary)', margin: '0 0 6px' } as const;

const secondaryButtonStyle = {
  background: 'var(--color-surface-raised)',
  border: '1px solid var(--color-border)',
  color: 'var(--color-text-primary)',
  borderRadius: 'var(--radius-md)',
  padding: 'var(--space-2) var(--space-4)',
  fontSize: 13,
  cursor: 'pointer',
} as const;

const primaryButtonStyle = {
  background: 'var(--color-accent)',
  border: 'none',
  color: '#fff',
  borderRadius: 'var(--radius-md)',
  padding: 'var(--space-2) var(--space-4)',
  fontSize: 13,
  fontWeight: 600,
  cursor: 'pointer',
} as const;
