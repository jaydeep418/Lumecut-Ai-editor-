# Photo Editor feature (Stage 3 — implemented)

Non-destructive Canvas 2D photo editor. The source image is never mutated — every
tool writes to `PhotoEditState` (see `types.ts`), and `canvasRenderer.ts` redraws the
whole thing from that state plus the original image on every change.

- `types.ts` — the edit state model (Adjustments, Transform, Layer, DrawingStroke)
- `history.ts` — generic undo/redo (editor-agnostic; Stage 4's video editor can reuse it)
- `canvasRenderer.ts` — pure render functions, no React
- `filters.ts` — filter presets as native Canvas 2D `ctx.filter` strings
- `cropMath.ts` — aspect-ratio-to-crop-rect math
- `usePhotoEditor.ts` — wires history + image loading + all edit actions
- `PhotoCanvas.tsx` / `CropOverlay.tsx` — the canvas surface and crop UI
- `PhotoEditor.tsx` — top-level screen, composes everything below
- `toolbars/` — one panel per tool tab (Crop, Adjust, Filters, Text, Stickers, Draw, AI)

AI-dependent tools (background removal/replacement, enhance, upscale, effects) are
real UI wired to `features/ai/photoAiService.ts`'s interface, but that service is a
stub until Stage 5 — no network calls, no API keys, see that file for the swap-in plan.

Export (turning this edit state into a downloadable file) is Stage 6.
