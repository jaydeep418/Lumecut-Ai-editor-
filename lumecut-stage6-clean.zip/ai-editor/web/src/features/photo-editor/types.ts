/**
 * Non-destructive photo edit state.
 *
 * The source image is never mutated. Everything here is small, serializable data —
 * numbers, short arrays of layer descriptions — never pixel buffers. The canvas is a
 * disposable render target: `renderPhotoEdit(canvas, sourceImage, state)` can always
 * reproduce the same output from `state` alone, which is what makes undo/redo, and
 * eventually persisting a project's edits, cheap.
 */
import type { FilterId } from '@/features/shared/filters';
export type { FilterId };

export interface Adjustments {
  /** All values are -100..100, 0 = no change, matching how sliders present them. */
  brightness: number;
  contrast: number;
  saturation: number;
  exposure: number;
  temperature: number; // negative = cooler/blue, positive = warmer/orange
  sharpness: number; // 0..100, 0 = off
  blur: number; // 0..20 (px of gaussian blur at render resolution)
}

export const NEUTRAL_ADJUSTMENTS: Adjustments = {
  brightness: 0,
  contrast: 0,
  saturation: 0,
  exposure: 0,
  temperature: 0,
  sharpness: 0,
  blur: 0,
};

/** Normalized crop rect, 0..1 relative to the ORIGINAL (unrotated) source image. */
export interface CropRect {
  x: number;
  y: number;
  width: number;
  height: number;
}

export interface Transform {
  /** Degrees, multiple of 90 — keeps rendering a simple axis-aligned drawImage call. */
  rotationDeg: 0 | 90 | 180 | 270;
  flipHorizontal: boolean;
  flipVertical: boolean;
  /** null = full image, no crop applied. */
  crop: CropRect | null;
  /** "Resize" per spec §2 — a target max dimension (longest edge, px) the user wants
   *  the final image capped to. null = use the source's natural size. Kept separate
   *  from `crop` (which selects a region) and from the export engine's own
   *  resolution presets (Stage 6, which govern the exported FILE's resolution) —
   *  this is the in-editor working-size preference, read by both. */
  targetMaxDimension: number | null;
}

export const IDENTITY_TRANSFORM: Transform = {
  rotationDeg: 0,
  flipHorizontal: false,
  flipVertical: false,
  crop: null,
  targetMaxDimension: null,
};

export interface TextLayer {
  id: string;
  type: 'text';
  text: string;
  /** Normalized 0..1 position, center-anchored, relative to the cropped output. */
  x: number;
  y: number;
  fontSize: number; // px, at output resolution scale of 1000 wide (see renderer)
  color: string;
  fontFamily: string;
  rotationDeg: number;
}

export interface StickerLayer {
  id: string;
  type: 'sticker';
  emoji: string;
  x: number;
  y: number;
  scale: number;
  rotationDeg: number;
}

export type Layer = TextLayer | StickerLayer;

/** Partial<Layer> alone would only expose keys common to BOTH variants (TypeScript
 *  computes `keyof` on a union as the intersection of each member's keys) — this
 *  union of partials is what `updateLayer` actually needs to accept a patch like
 *  `{ text: ... }` or `{ color: ... }`. */
export type LayerPatch = Partial<TextLayer> & Partial<StickerLayer>;

export interface DrawingStroke {
  id: string;
  /** Normalized 0..1 points relative to the cropped output. */
  points: Array<{ x: number; y: number }>;
  color: string;
  size: number; // stroke width, px at output resolution scale of 1000 wide
}

export interface PhotoEditState {
  transform: Transform;
  adjustments: Adjustments;
  filter: FilterId;
  layers: Layer[];
  strokes: DrawingStroke[];
}

export function createInitialPhotoEditState(): PhotoEditState {
  return {
    transform: IDENTITY_TRANSFORM,
    adjustments: NEUTRAL_ADJUSTMENTS,
    filter: 'none',
    layers: [],
    strokes: [],
  };
}
