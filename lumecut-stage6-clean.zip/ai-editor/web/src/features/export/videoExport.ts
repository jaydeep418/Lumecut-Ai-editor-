import { getSessionId } from '@services/sessionId';
import type { VideoEditState } from '../video-editor/types';

const API_BASE_URL = import.meta.env.VITE_API_BASE_URL ?? 'http://localhost:8787';
const POLL_INTERVAL_MS = 1000;

export interface VideoExportOptions {
  width: number;
  height: number;
  fps: 24 | 30 | 60;
  quality: 'standard' | 'high' | 'ultra';
}

export type VideoExportStatus = 'uploading' | 'queued' | 'probing' | 'processing' | 'done' | 'error' | 'cancelled';

export interface VideoExportProgress {
  status: VideoExportStatus;
  /** 0..1. Meaningful during 'processing'; FFmpeg's own real progress, parsed
   *  server-side from its `-progress` output — not simulated. */
  progressRatio: number;
  resultBlob?: Blob;
  message?: string;
}

export interface VideoExportHandle {
  cancel: () => void;
}

async function blobUrlToBlob(sourceUrl: string): Promise<Blob> {
  const response = await fetch(sourceUrl);
  if (!response.ok) throw new Error('Could not read a local clip to upload for export.');
  return response.blob();
}

/**
 * Real, server-side FFmpeg export (Stage 6 upgrade). Uploads each clip's
 * actual bytes (deduped by source — a split clip's two halves upload once)
 * plus a JSON manifest describing the EDL, then polls the backend job's
 * progress until it's done, then downloads the real MP4 FFmpeg produced.
 *
 * Deliberately NOT MediaRecorder-based: this reflects an actual FFmpeg process
 * running server-side, not a browser real-time canvas capture.
 */
export function exportVideo(
  editState: VideoEditState,
  options: VideoExportOptions,
  onProgress: (progress: VideoExportProgress) => void
): VideoExportHandle {
  let cancelled = false;
  let jobId: string | null = null;
  let pollTimer: ReturnType<typeof setTimeout> | null = null;

  async function run() {
    if (editState.clips.length === 0) {
      onProgress({ status: 'error', progressRatio: 0, message: 'Nothing to export — add at least one clip first.' });
      return;
    }

    onProgress({ status: 'uploading', progressRatio: 0 });

    // Dedupe by sourceUrl: a split clip's two halves share one source file —
    // upload it once, reference it from both manifest entries.
    const sourceKeyByUrl = new Map<string, string>();
    for (const clip of editState.clips) {
      if (!sourceKeyByUrl.has(clip.sourceUrl)) {
        sourceKeyByUrl.set(clip.sourceUrl, `source_${sourceKeyByUrl.size}`);
      }
    }

    const formData = new FormData();
    try {
      for (const [sourceUrl, sourceKey] of sourceKeyByUrl) {
        const blob = await blobUrlToBlob(sourceUrl);
        formData.append(sourceKey, blob, `${sourceKey}.mp4`);
      }
    } catch (err) {
      onProgress({
        status: 'error',
        progressRatio: 0,
        message: err instanceof Error ? err.message : 'Could not read a clip for upload.',
      });
      return;
    }
    if (cancelled) return;

    const manifest = {
      clips: editState.clips.map((clip) => ({
        id: clip.id,
        sourceKey: sourceKeyByUrl.get(clip.sourceUrl),
        inPoint: clip.inPoint,
        outPoint: clip.outPoint,
        speed: clip.speed,
        reversed: clip.reversed,
        volume: clip.volume,
        muted: clip.muted,
        rotationDeg: clip.rotationDeg,
        flipHorizontal: clip.flipHorizontal,
        flipVertical: clip.flipVertical,
        filter: clip.filter,
      })),
      transitions: editState.transitions.map((t) => ({ afterClipId: t.afterClipId, type: t.type, duration: t.duration })),
      overlays: editState.overlays.map((o) =>
        o.type === 'text'
          ? {
              type: 'text',
              text: o.text,
              startTime: o.startTime,
              endTime: o.endTime,
              x: o.x,
              y: o.y,
              rotationDeg: o.rotationDeg,
              fontSize: o.fontSize,
              color: o.color,
              fontFamily: o.fontFamily,
            }
          : {
              type: 'sticker',
              emoji: o.emoji,
              startTime: o.startTime,
              endTime: o.endTime,
              x: o.x,
              y: o.y,
              rotationDeg: o.rotationDeg,
              scale: o.scale,
            }
      ),
      width: options.width,
      height: options.height,
      fps: options.fps,
      quality: options.quality,
    };
    formData.append('manifest', JSON.stringify(manifest));

    let response: Response;
    try {
      response = await fetch(`${API_BASE_URL}/api/export/video`, {
        method: 'POST',
        headers: { 'X-Session-Id': getSessionId() },
        body: formData,
      });
    } catch {
      onProgress({ status: 'error', progressRatio: 0, message: 'Could not reach the export server.' });
      return;
    }
    if (cancelled) return;

    const data = await response.json().catch(() => ({}) as { jobId?: string; message?: string });
    if (!response.ok || !data.jobId) {
      onProgress({ status: 'error', progressRatio: 0, message: data.message ?? 'Export failed to start.' });
      return;
    }

    jobId = data.jobId;
    onProgress({ status: 'queued', progressRatio: 0 });
    schedulePoll();
  }

  function schedulePoll() {
    if (cancelled || !jobId) return;
    pollTimer = setTimeout(poll, POLL_INTERVAL_MS);
  }

  async function poll() {
    if (cancelled || !jobId) return;
    try {
      const res = await fetch(`${API_BASE_URL}/api/export/video/${jobId}/progress`, {
        headers: { 'X-Session-Id': getSessionId() },
      });
      const data = (await res.json()) as { status: VideoExportStatus; progressRatio: number; message?: string };
      if (cancelled) return;

      if (data.status === 'done') {
        await downloadResult();
      } else if (data.status === 'error') {
        onProgress({ status: 'error', progressRatio: data.progressRatio, message: data.message ?? 'Export failed.' });
      } else if (data.status === 'cancelled') {
        onProgress({ status: 'cancelled', progressRatio: 0, message: 'Export cancelled.' });
      } else {
        onProgress({ status: data.status, progressRatio: data.progressRatio });
        schedulePoll();
      }
    } catch {
      onProgress({ status: 'error', progressRatio: 0, message: 'Lost connection to the export server.' });
    }
  }

  async function downloadResult() {
    if (!jobId) return;
    try {
      const res = await fetch(`${API_BASE_URL}/api/export/video/${jobId}/result`, {
        headers: { 'X-Session-Id': getSessionId() },
      });
      if (!res.ok) throw new Error('Could not download the exported file.');
      const blob = await res.blob();
      onProgress({ status: 'done', progressRatio: 1, resultBlob: blob });
    } catch (err) {
      onProgress({
        status: 'error',
        progressRatio: 1,
        message: err instanceof Error ? err.message : 'Could not download the exported file.',
      });
    }
  }

  function cancel() {
    if (cancelled) return;
    cancelled = true;
    if (pollTimer) clearTimeout(pollTimer);
    if (jobId) {
      fetch(`${API_BASE_URL}/api/export/video/${jobId}/cancel`, {
        method: 'POST',
        headers: { 'X-Session-Id': getSessionId() },
      }).catch(() => {});
    }
    onProgress({ status: 'cancelled', progressRatio: 0, message: 'Export cancelled.' });
  }

  run();
  return { cancel };
}
