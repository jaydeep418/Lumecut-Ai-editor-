import { renderPhotoEdit, type LoadedImage } from '../photo-editor/canvasRenderer';
import type { PhotoEditState } from '../photo-editor/types';

/** The crop tool (Stage 3) can leave the photo at a different aspect ratio than
 *  the project's original `aspectRatio` field — export should honor whatever the
 *  edit state ACTUALLY produces, not the stale project metadata. */
export function getEffectiveAspectRatio(image: LoadedImage, state: PhotoEditState): { w: number; h: number } {
  const crop = state.transform.crop;
  const sw = crop ? crop.width * image.width : image.width;
  const sh = crop ? crop.height * image.height : image.height;
  const rotated = state.transform.rotationDeg === 90 || state.transform.rotationDeg === 270;
  return rotated ? { w: sh, h: sw } : { w: sw, h: sh };
}

export type ImageExportFormat = 'png' | 'jpeg';

export interface ImageExportOptions {
  width: number;
  height: number;
  format: ImageExportFormat;
  /** 0..1, only meaningful for 'jpeg' (PNG is always lossless). */
  quality: number;
}

/**
 * Renders `state` at the EXACT requested `width`/`height` — not the editor's
 * capped working resolution — and encodes it to a real image file. If the
 * source photo is smaller than the requested resolution, this upscales via the
 * canvas draw (same as any editor's manual resize); it does not invoke Stage 5's
 * AI upscaler, which remains a separate, explicit tool.
 */
export function exportPhotoToBlob(image: LoadedImage, state: PhotoEditState, options: ImageExportOptions): Promise<Blob> {
  const canvas = document.createElement('canvas');
  renderPhotoEdit(canvas, image, state, { exactOutputSize: { width: options.width, height: options.height } });

  const mimeType = options.format === 'png' ? 'image/png' : 'image/jpeg';
  return new Promise((resolve, reject) => {
    canvas.toBlob(
      (blob) => {
        if (blob) resolve(blob);
        else reject(new Error('Export failed: the browser could not encode this image.'));
      },
      mimeType,
      options.format === 'jpeg' ? options.quality : undefined
    );
  });
}

/** Triggers a real browser download for the given blob — no server round trip
 *  needed for a file that already exists entirely in the browser. */
export function downloadBlob(blob: Blob, filename: string): void {
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  // Give the browser a moment to actually start the download before revoking.
  setTimeout(() => URL.revokeObjectURL(url), 2000);
}
