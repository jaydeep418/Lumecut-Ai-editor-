import { useCallback, useRef, useState } from 'react';

const MAX_HISTORY = 50;

interface UseHistoryStateResult<T> {
  state: T;
  /** Push a new state onto the undo stack (clears any redo stack ahead of it). The
   *  undo entry recorded is the last COMMITTED baseline, not necessarily the current
   *  `state` — see `setLive`. */
  commit: (next: T) => void;
  /** Replace the current state WITHOUT creating a history entry or moving the
   *  committed baseline — for continuous live-preview updates (e.g. dragging a
   *  slider). Call `commit` once, when the interaction ends, to record it. */
  setLive: (next: T) => void;
  undo: () => void;
  redo: () => void;
  canUndo: boolean;
  canRedo: boolean;
}

/**
 * Generic undo/redo over a small, serializable state object (not pixel data — see
 * PhotoEditState). Kept editor-agnostic so Stage 4's video editor can reuse it.
 *
 * `setLive` vs `commit` is what keeps a slider drag from flooding the history stack:
 * dragging calls `setLive` on every tick (visual-only), and a single `commit` on
 * release records ONE undo step — diffed against the baseline from before the drag
 * started, not the in-progress value, via the `lastCommitted` ref below.
 */
export function useHistoryState<T>(initial: T): UseHistoryStateResult<T> {
  const [state, setState] = useState<T>(initial);
  const lastCommitted = useRef<T>(initial);
  const undoStack = useRef<T[]>([]);
  const redoStack = useRef<T[]>([]);
  // Forces a re-render after mutating the refs above (canUndo/canRedo read them
  // directly) without duplicating history into React state.
  const [, forceRender] = useState(0);

  const commit = useCallback((next: T) => {
    undoStack.current.push(lastCommitted.current);
    if (undoStack.current.length > MAX_HISTORY) undoStack.current.shift();
    redoStack.current = [];
    lastCommitted.current = next;
    setState(next);
    forceRender((n) => n + 1);
  }, []);

  const setLive = useCallback((next: T) => {
    setState(next);
  }, []);

  const undo = useCallback(() => {
    const previous = undoStack.current.pop();
    if (previous === undefined) return;
    redoStack.current.push(lastCommitted.current);
    lastCommitted.current = previous;
    setState(previous);
    forceRender((n) => n + 1);
  }, []);

  const redo = useCallback(() => {
    const next = redoStack.current.pop();
    if (next === undefined) return;
    undoStack.current.push(lastCommitted.current);
    lastCommitted.current = next;
    setState(next);
    forceRender((n) => n + 1);
  }, []);

  return {
    state,
    commit,
    setLive,
    undo,
    redo,
    canUndo: undoStack.current.length > 0,
    canRedo: redoStack.current.length > 0,
  };
}
