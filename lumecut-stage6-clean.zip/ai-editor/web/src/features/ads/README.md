# Ads feature
Populated in Stage 7: banner/interstitial/rewarded ad components behind a provider-
agnostic interface, so AdMob (or another network) can be swapped without touching
call sites. No ad unit IDs are hardcoded — see .env.example.
