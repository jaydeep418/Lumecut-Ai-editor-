/**
 * Central HTTP client for talking to the Lumecut backend.
 *
 * IMPORTANT: this file must never import or reference a secret API key. The frontend
 * only ever knows the backend's base URL (public) and, later, the current user's auth
 * token (obtained via login, not baked in). Every AI/payment/ad-network secret lives
 * server-side only — see server/src/services/{ai,payments,ads}.
 */

const API_BASE_URL = import.meta.env.VITE_API_BASE_URL ?? 'http://localhost:8787';

export class ApiError extends Error {
  constructor(
    message: string,
    public status: number
  ) {
    super(message);
    this.name = 'ApiError';
  }
}

async function request<T>(path: string, init?: RequestInit): Promise<T> {
  const response = await fetch(`${API_BASE_URL}${path}`, {
    headers: { 'Content-Type': 'application/json' },
    ...init,
  });

  if (!response.ok) {
    throw new ApiError(`Request to ${path} failed`, response.status);
  }

  return response.json() as Promise<T>;
}

export interface HealthResponse {
  status: 'ok';
  stage: number;
}

export function checkBackendHealth(): Promise<HealthResponse> {
  return request<HealthResponse>('/api/health');
}
