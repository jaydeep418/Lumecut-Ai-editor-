const SESSION_ID_KEY = 'lumecut.sessionId';

/**
 * A random id persisted in localStorage, sent as X-Session-Id on AI requests so
 * the backend's demo-grade usage limiter (server/src/middleware/usageLimiter.ts)
 * can count requests per browser before real accounts exist (Stage 9). Not a
 * security credential — a client can trivially clear it to reset their count,
 * which is fine for a pre-auth demo limit and explicitly documented as such.
 */
export function getSessionId(): string {
  let id = localStorage.getItem(SESSION_ID_KEY);
  if (!id) {
    id = crypto.randomUUID();
    localStorage.setItem(SESSION_ID_KEY, id);
  }
  return id;
}
