export type ProjectKind = 'photo' | 'video';

/** The four export-relevant aspect ratios from the product spec (§3). Stored on the
 *  project at creation time so the photo/video editor (Stage 3/4) and export engine
 *  (Stage 6) can read it without re-deriving it from the source file. */
export type AspectRatioId = '9:16' | '16:9' | '1:1' | '4:5';

export interface Project {
  id: string;
  name: string;
  kind: ProjectKind;
  aspectRatio: AspectRatioId;
  /** Object URL for the source file. Valid only for this browser session (Stage 2 —
   *  no persistence yet; Stage 9 replaces this with a real uploaded asset URL). */
  previewUrl: string;
  createdAt: number;
}
