import type { AspectRatioId } from '@types/project';

export interface AspectRatioOption {
  id: AspectRatioId;
  label: string;
  w: number;
  h: number;
}

// Mirrors config/app.config.json's `aspectRatios` block — kept as a small local
// constant (rather than importing the JSON across the web/server boundary) so web/
// stays independently deployable, per server/src/types/README.md's stated rule.
export const ASPECT_RATIOS: AspectRatioOption[] = [
  { id: '9:16', label: '9:16', w: 9, h: 16 },
  { id: '16:9', label: '16:9', w: 16, h: 9 },
  { id: '1:1', label: '1:1', w: 1, h: 1 },
  { id: '4:5', label: '4:5', w: 4, h: 5 },
];

export const DEFAULT_ASPECT_RATIO: AspectRatioId = '9:16';
