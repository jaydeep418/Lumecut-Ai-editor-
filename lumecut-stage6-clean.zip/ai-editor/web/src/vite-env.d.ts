/// <reference types="vite/client" />

interface ImportMetaEnv {
  /** Base URL of the backend API. Public — never a secret. */
  readonly VITE_API_BASE_URL: string;

  // --- Introduced in later stages, declared now so the shape is stable ---

  /** Stage 8: Stripe/RevenueCat publishable key (public by design, not secret). */
  readonly VITE_BILLING_PUBLISHABLE_KEY?: string;

  /** Stage 7: AdMob app ID (public, embedded in the app manifest). */
  readonly VITE_ADMOB_APP_ID?: string;

  /** Stage 9: Firebase/Supabase public client config (safe to expose by design). */
  readonly VITE_AUTH_PUBLIC_API_KEY?: string;
  readonly VITE_AUTH_PROJECT_ID?: string;
}

interface ImportMeta {
  readonly env: ImportMetaEnv;
}
