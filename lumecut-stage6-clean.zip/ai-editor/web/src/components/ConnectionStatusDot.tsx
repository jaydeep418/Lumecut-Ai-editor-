import { useEffect, useState } from 'react';
import { checkBackendHealth } from '@services/api';

type Status = 'checking' | 'ok' | 'unreachable';

/** Tiny, unobtrusive backend status indicator — not a Stage 1 diagnostics page, just
 *  a corner dot so connectivity problems are visible without opening dev tools. */
export function ConnectionStatusDot() {
  const [status, setStatus] = useState<Status>('checking');

  useEffect(() => {
    let cancelled = false;
    checkBackendHealth()
      .then(() => !cancelled && setStatus('ok'))
      .catch(() => !cancelled && setStatus('unreachable'));
    return () => {
      cancelled = true;
    };
  }, []);

  const color =
    status === 'ok'
      ? 'var(--color-success)'
      : status === 'unreachable'
        ? 'var(--color-danger)'
        : 'var(--color-text-secondary)';

  const title =
    status === 'ok'
      ? 'Backend connected'
      : status === 'unreachable'
        ? 'Backend unreachable — start the server (see README)'
        : 'Checking backend…';

  return (
    <span
      title={title}
      aria-label={title}
      style={{
        display: 'inline-block',
        width: 8,
        height: 8,
        borderRadius: '50%',
        background: color,
      }}
    />
  );
}
