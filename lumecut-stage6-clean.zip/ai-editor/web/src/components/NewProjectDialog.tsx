import { useState, type CSSProperties } from 'react';
import { ASPECT_RATIOS, DEFAULT_ASPECT_RATIO } from '@/constants/aspectRatios';
import type { AspectRatioId } from '@types/project';

interface NewProjectDialogProps {
  file: File;
  onCancel: () => void;
  onConfirm: (name: string, aspectRatio: AspectRatioId) => void;
}

function defaultNameFor(file: File): string {
  return file.name.replace(/\.[^/.]+$/, '') || 'Untitled project';
}

export function NewProjectDialog({ file, onCancel, onConfirm }: NewProjectDialogProps) {
  const defaultName = defaultNameFor(file);
  const [name, setName] = useState(defaultName);
  const [aspectRatio, setAspectRatio] = useState<AspectRatioId>(DEFAULT_ASPECT_RATIO);

  return (
    <div style={overlayStyle} role="dialog" aria-modal="true" aria-label="New project details">
      <div style={dialogStyle}>
        <h2 style={{ fontSize: 16, margin: 0 }}>New Project</h2>

        <label style={{ display: 'flex', flexDirection: 'column', gap: 6, fontSize: 13 }}>
          Project name
          <input
            autoFocus
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder={defaultName}
            style={inputStyle}
          />
        </label>

        <div>
          <p style={{ fontSize: 13, margin: '0 0 6px' }}>Aspect ratio</p>
          <div style={{ display: 'flex', gap: 'var(--space-2)', flexWrap: 'wrap' }}>
            {ASPECT_RATIOS.map((ratio) => {
              const active = aspectRatio === ratio.id;
              return (
                <button
                  key={ratio.id}
                  type="button"
                  onClick={() => setAspectRatio(ratio.id)}
                  aria-pressed={active}
                  style={active ? { ...chipStyle, ...chipActiveStyle } : chipStyle}
                >
                  {ratio.label}
                </button>
              );
            })}
          </div>
        </div>

        <div style={{ display: 'flex', gap: 'var(--space-2)', justifyContent: 'flex-end', marginTop: 'var(--space-2)' }}>
          <button type="button" onClick={onCancel} style={secondaryButtonStyle}>
            Cancel
          </button>
          <button
            type="button"
            onClick={() => onConfirm(name.trim() || defaultName, aspectRatio)}
            style={primaryButtonStyle}
          >
            Create
          </button>
        </div>
      </div>
    </div>
  );
}

const overlayStyle: CSSProperties = {
  position: 'fixed',
  inset: 0,
  background: 'rgba(0, 0, 0, 0.6)',
  display: 'flex',
  alignItems: 'flex-end',
  justifyContent: 'center',
  zIndex: 100,
};

const dialogStyle: CSSProperties = {
  width: '100%',
  maxWidth: 480,
  background: 'var(--color-surface)',
  borderTop: '1px solid var(--color-border)',
  borderTopLeftRadius: 'var(--radius-lg)',
  borderTopRightRadius: 'var(--radius-lg)',
  padding: 'var(--space-5) var(--space-4)',
  paddingBottom: 'calc(var(--space-5) + env(safe-area-inset-bottom))',
  display: 'flex',
  flexDirection: 'column',
  gap: 'var(--space-4)',
};

const inputStyle: CSSProperties = {
  background: 'var(--color-surface-raised)',
  border: '1px solid var(--color-border)',
  borderRadius: 'var(--radius-sm)',
  color: 'var(--color-text-primary)',
  padding: 'var(--space-2) var(--space-3)',
  fontSize: 14,
};

const chipStyle: CSSProperties = {
  background: 'var(--color-surface-raised)',
  border: '1px solid var(--color-border)',
  color: 'var(--color-text-secondary)',
  borderRadius: 'var(--radius-pill)',
  padding: 'var(--space-2) var(--space-3)',
  fontSize: 13,
  cursor: 'pointer',
};

const chipActiveStyle: CSSProperties = {
  background: 'var(--color-accent)',
  borderColor: 'var(--color-accent)',
  color: '#fff',
};

const secondaryButtonStyle: CSSProperties = {
  background: 'var(--color-surface-raised)',
  border: '1px solid var(--color-border)',
  color: 'var(--color-text-primary)',
  borderRadius: 'var(--radius-md)',
  padding: 'var(--space-2) var(--space-4)',
  fontSize: 14,
  cursor: 'pointer',
};

const primaryButtonStyle: CSSProperties = {
  background: 'var(--color-accent)',
  border: 'none',
  color: '#fff',
  borderRadius: 'var(--radius-md)',
  padding: 'var(--space-2) var(--space-4)',
  fontSize: 14,
  fontWeight: 600,
  cursor: 'pointer',
};
