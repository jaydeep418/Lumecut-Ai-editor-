import { useRef, useState, type ChangeEvent, type ReactNode } from 'react';
import { useNavigate } from 'react-router-dom';
import { useProjects } from '@/state/ProjectsContext';
import { NewProjectDialog } from '@components/NewProjectDialog';
import type { AspectRatioId, ProjectKind } from '@types/project';

interface NewProjectButtonProps {
  /** Restrict the picker to one media kind, or leave undefined to accept either
   *  and infer kind from the chosen file's MIME type. */
  kind?: ProjectKind;
  children: ReactNode;
  variant?: 'primary' | 'secondary';
}

interface PendingFile {
  file: File;
  kind: ProjectKind;
}

const ACCEPT: Record<ProjectKind | 'any', string> = {
  photo: 'image/*',
  video: 'video/*',
  any: 'image/*,video/*',
};

export function NewProjectButton({ kind, children, variant = 'primary' }: NewProjectButtonProps) {
  const inputRef = useRef<HTMLInputElement>(null);
  const { createProject } = useProjects();
  const navigate = useNavigate();
  const [pending, setPending] = useState<PendingFile | null>(null);

  function handleFile(e: ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    e.target.value = ''; // allow picking the same file again later
    if (!file) return;

    const resolvedKind: ProjectKind = kind ?? (file.type.startsWith('video/') ? 'video' : 'photo');
    // Don't create the project yet — the dialog collects the name and aspect ratio first.
    setPending({ file, kind: resolvedKind });
  }

  function handleConfirm(name: string, aspectRatio: AspectRatioId) {
    if (!pending) return;
    const project = createProject(pending.file, pending.kind, name, aspectRatio);
    setPending(null);
    navigate(`/editor/${project.id}`);
  }

  const style =
    variant === 'primary'
      ? {
          background: 'var(--color-accent)',
          color: '#fff',
          border: 'none',
        }
      : {
          background: 'var(--color-surface-raised)',
          color: 'var(--color-text-primary)',
          border: '1px solid var(--color-border)',
        };

  return (
    <>
      <button
        type="button"
        onClick={() => inputRef.current?.click()}
        style={{
          ...style,
          borderRadius: 'var(--radius-md)',
          padding: 'var(--space-3) var(--space-4)',
          fontWeight: 600,
          fontSize: 15,
          cursor: 'pointer',
        }}
      >
        {children}
      </button>
      <input
        ref={inputRef}
        type="file"
        accept={ACCEPT[kind ?? 'any']}
        onChange={handleFile}
        style={{ display: 'none' }}
      />
      {pending && (
        <NewProjectDialog
          file={pending.file}
          onCancel={() => setPending(null)}
          onConfirm={handleConfirm}
        />
      )}
    </>
  );
}
